Port Scanner v1.0 (bdimag@cox.net)
=========================================

Installation:

 -Copy the files to your main mIRC folder
 -In mIRC type: /load -rs portscan.mrc


Usage:

 -From the menubar, go to "Port Scanner", or type the command /portscanner
 -Enter a host or IP into the box, enter a rage of ports to scan, timeout, and hit "START"
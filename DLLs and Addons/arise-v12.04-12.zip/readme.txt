Arise v1.2 - Copyright (c) 2004-2005 bliP
20 January 2005 - 8 February 2005
Email: blip@tranquility.net.nz
Web: http://blip.nevada.net.nz/
IRC: #nzgames irc.enterthegame.com


Arise is a tray popup DLL, mainly for mIRC.
Requires mIRC v6.16 but will probably work with older versions.


Copy arise.dll and arise.mrc into your \mIRC directory.
Open mIRC and type:
  /load -rs arise.mrc
Push Yes to run init commands.


Commands:
  /ar - toggles popups
  /arise_example - example


Tips:
  Right click on popup sticks it there until...
  Left click removes popup immediately


Customising Popups:
  Tools -> Script Editor -> Variables
  The variables are called %arise_<name> and the value is delimited by the ASCII
  character "�" (183, the Verdana font in charmap calls it "Middle dot")
  For clarity here and so this file will be easier to read in any font, I'll use
  "+" instead.

  %arise_text Verdana+8+2+0,0,0+Verdana+8+1+0,0,0+174,219,255+7000

  Verdana     - Title font name
  8           - Title font size
  2           - Title font style
  0,0,0       - Title font colour
  Verdana     - Body font name
  8           - Body font size
  1           - Body font style
  0,0,0       - Body font colour
  174,219,255 - Background colour
  7000        - On screen time (ms)

  Notes:
    - Colour is in RGB format: Red 128, Green 255, Blue 255 is Aqua
      Written as 128,255,255 make sure there are no spaces.

    - On screen time is in milliseconds, 1 second is 1000 milliseconds.

    - Font style:
      Normal - 1
      Bold - 2
      Italic - 4
      Underline - 8
      To use more than one style at a time, add them together, for example:
      Bold and italic is a value of 6 (2+4). Bold, italic and underline would
      be 14 (2+4+8).


Scripting:
  For full customisation, basic mIRC scripting is required. Please refer to mIRC's
  help for more information and/or a tutorial from http://www.mircscripts.org/
  You cannot trigger your own text events.

  Tools -> Script Editor -> Remote (choose arise.mrc from the view menu if it is
  not the current file)

  The $arise identifier displays popups
    $arise(<settings>,<title text>,<body text>)

  Popups are shown when certain events occur
    on 1:TEXT:*:#:{ $arise(%arise_text,$nick � $_userprefix $+ $chan,$1-) }

    on TEXT - Channel/private messages
    * - Matches all text
    # - From any channel (? means private message)
    $arise - Display a popup
    %arise_text - Text settings
    $nick - Person who talked (built in)
    $_userprefix - @ for op, % for half op, + for voice, nothing for normal (custom)
    $+ - Put too words together
    $chan - Channel text is from
    $1- - The text itself

  Sometimes you might not want popups to be displayed for a certain channel
    Only trigger for channels #foo and #bar but not #foobar
      on 1:TEXT:*:#foo,#bar:{ <snip> }
    To disable a trigger permanently comment it out with the ";" character
      ;on 1:QUIT:{ <snip> }


Example to add a special popup for nick highlight:
  Tools -> Script Editor -> Variables
    Add (remember to replace "+" with the special character "�" as explained above):

      %arise_highlight Times New Roman+12+6+45,255,25+Arial+10+1+255,240,132+220,0,20+4500

    Times New Roman, 12pt, bold, italic and light green colour title text.
    Arial, 10pt, normal and light yellow colour body text.
    Dark red background which stays on screen for 4.5 seconds.
    It looks absolutely terrible but hopefully you get the idea.

  Tools -> Script Editor -> Remote (arise.mrc)
    Add (must be before the catch-all * on TEXT):

     on 1:TEXT:$(* $+ $me $+ *):*:{ $arise(%arise_highlight,$nick $_userprefix $+ $chan,$1-) }

    This will match your nickname.

  Push OK and wait for someone to say your name.


Technical Information:
  This DLL can be used by other programs and is not limited to mIRC.
  The file arise.h contains the header for calling arise.dll, make sure to keep the DLL loaded
  so popups will be able to position themselves correctly.

  HWND mWnd - NULL
  HWND aWnd - NULL
  char *data - Full settings, 900 characters
  char *parms - Response buffer, 900 characters
  BOOL show - 0
  BOOL nopause - 0


Disclaimer:
Any use by you of the software is at your own risk. The software is
provided for use "as is" without warranty of any kind. This software
is released as "freeware". Redistribution is only allowed if the
software is unmodified, no fee is charged for the software, directly
or indirectly without the express permission of the author.

-bliP
"Because I Can."
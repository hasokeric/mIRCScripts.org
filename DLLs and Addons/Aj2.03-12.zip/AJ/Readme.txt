Autojoin IRC v2.0 by shawken@utk.edu

It took me a while to update this, not because I do not have time just because I forgot about it ;) But finally I have deleted all my previous code and remade the entire thing(because I used to code stupidly).. All the bugs that were reported have been taken out and some features have been added.  If you would like to join a channel that has a key just add the channel as #channel KEY and it will use the key to join.


Installation: 

Extract this zip to your system mirc dir containing mirc32.exe and type /load -rs AJ\aj.mrc


Config and Understanding:

Autojoin IRC is intended for irc users who connect to more than one IRC net and join different channels on each one, which would defeat the purpose of the on connect commands.  Autojoin IRC lets irc users specify nets, their servers, and specific channels to join for different nets.  Once the nets are added and configured you can either double click on the server you want, or just type /connect and you will join that network's channels(assuming Autojoin is turned on).  If you have turned Autojoin off you can also join the channels by selecting "Join net chans" in the popup menus.  At anytime if you want to popup the Options dialog it is accessed through any popup , or you can just press f12, assuming it is not used by other scripts you have loaded. 



Enjoy and email comments and questions to shawken@utk.edu
These are just the default buttons from Winamp 3 at 22x18.
also included are the same buttons just colored with green/red to show them as being activated.

Files Included.
15 Icons (*.ico)
15 Bitmaps (*.bmp)
1 Icon Library (*.icl)
1 Readme (readme.txt)

* 32 Files total

Just something for anyone to use in their mp3 script if they like :) I am currently working on an MP3 Player using these icons which I will release the script once I am finished (If I actually ever finish)

Enjoy

BLackCrypton
blackcrypton@hotmail.com
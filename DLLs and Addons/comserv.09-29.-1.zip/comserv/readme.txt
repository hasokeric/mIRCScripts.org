==============================
Common servers v1.0 - by Andy
==============================

Basic Description: 
This addon connects to YOUR common servers either on START or through the menubar

Contents:
This .zip file should include:
comserv.mrc - 5KB
mdx.dll - 41.5KB
views.mdx - 53KB
readme.txt - 2KB

Installation:
1. Extract the file anywhere you like on your system
2. In mIRC, type /load -rs X:\path\to\comserv\comserv.mrc


Usage:
To manage your common servers list, simple type /csmanage - or you can get to the management dialog via the Menubar.
When you've opened the dialog you can start adding servers at the click of 'Add' and proceed to edit servers or remove them
with their respective buttons.

You can toggle the startup prompt with the left hand checkbox, and the auto joining of channels on CONNECT with the right hand one.

Credits:
Dragonzap - mdx.dll and views.mdx
Khaled - mIRC

Bugs/Comments/Suggestions:
If you find any bugs or wish to comment or suggest something on the addon please feel free to e-mail me at palmer.andy@gmail.com


Thanks, Andy

 +----------------------------------------------------------------------------+
 |               Boxes! version 1.0 by spling -- Documentation                |`.
 +----------------------------------------------------------------------------+ |
 | Installation:                                                              | |
 | 	step 1. Extract the files "boxes.ini" and "box.mrc" to your mIRC      | |
 |		directory.                                                    | |
 |	step 2. Use the following command in mIRC:                            | | 
 |			/load -rs box.mrc                                     | |
 |	step3. Click "yes" to an initialization command warnings.             | |
 |                                                                            | |
 |                               +-------+                                    | |
 |                                                                            | |
 | Usage Instructions:                                                        | |
 |                                                                            | |
 |	When the script is first loaded, the main box window will pop up.     | |
 |	All you have to do is choose which theme you want to use for your     | |
 |	boxed text, and fill in the "Box it.." field, and hit the "Box it.."  | |
 |	button.                                                               | |
 |                                                                            | |
 |	You can bring the window up at any time with the "/box" command.      | |
 |	There is also an "Add theme" button, so you can make your own         | |
 |	theme if you don't like the premade ones.                             | |
 |                                                                            | |
 |		Make sure you use numbers in the first three fields. You      | |
 |		can include the color chartacter too, but it's not required.  | |
 |		Also, be sure that your theme title isn't the same title      | |
 |		as any existing themes.                                       | |
 +----------------------------------------------------------------------------+ |
 | Any questions  or problems can be forwarded  to spling at irc.crazyirc.net | |
 | channel #opers or you can email me at spling@gmail.com.                    | |
 |								Thank you!    | |
 +============================================================================+ |
 | Note: This script is only authorized for download from www.mircscripts.org | |
 | If you got this script anywhere  else, please |delete it, as  the contents | |
 | of  the script  may  be  dangerous. Please  download  a  clean  copy  from | |
 | www.mircscripts.org if this is the case.                                   | |
 +----------------------------------------------------------------------------+ |
  `.___________________________________________________________________________`.
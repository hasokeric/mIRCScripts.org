DragonBall Z - By Epsilon - www.picwin.tk
-----------------------------------------

To load the game, extract all the files to a directory, and type:

/load -rs "C:\my directory\DBZ.mrc"

where "my directory" is the path where you've extracted the files.
You can now launch the game by typing /dbz, or with the menu.

-----------------------------------------

Default keys (you can change them in the options)

Jump, left, right, down = arrows
Select a fighter = Enter
Punch = A
Kick = Z
High Kick = Q
Block = S
Fireball = E

You can use the joystick but you cannot configure it atm (I need to borrow a joystick from someone first), so use the default config until the next update.

-----------------------------------------

If you want to host a game, make sure that you have a good connection and a good computer, hosting asks a lot of ressources.
But you can play with a low configuration (Pentium II 266Mhz).

-----------------------------------------

DLLs.

- x-GUI: GUI and joystick support. It's an unofficial version of x-GUI, I'll not provide any support with this version of the DLL. 
- Game Tools: provide an accurate ticks value.
- mUnzip: unzipping of the updates.

-----------------------------------------

Cheating.

Cheating is only possible server side, that means that if you are the server, nobody can cheat. Normals players cannot affect the game with "cheats". If you see some weird thing like infinite life, the server might run under a modified version of DragonBall Z. You should only play with people that you trust.

To cheaters-wanabe: Please, I've spent a lot of time to make that game, you don't have to pay anything to play, so do not try to ruin the fun of everyone with cheats. The future of mIRC games depends of the users.

-----------------------------------------

Credits.

Sprites : from DragonBall Z - Legendary Super Warriors (�Bandai) 
Color version by www.enpitsudo-dojo.com
Backgrounds & sounds : from Dragon Ball Z - Hyper Dimension (�Bandai)
DragonBall Z is copyright Bird Studio/Shueisha Toei Animation
This is just a free non-official game made by a fan.

-----------------------------------------

Special Thanks.

Greetz to StanZ, ToKeN, Sandra & visionz.
PicWin.tk users.
Exolia.net users, for the beta testing.
antygone, for being the best girl in the world.
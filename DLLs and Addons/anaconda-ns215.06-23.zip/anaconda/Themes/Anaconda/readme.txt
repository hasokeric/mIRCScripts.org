Intro:

This is Anac�n�a MTS theme version 2.1 dedicated to Anac�n�a mIRC script, written by Snake.

It contains 6 schemes, 2 dark and 5 white. It also contains some background images.

You'll need an mts engine that supports MTS format version 1.3.

How to install:

It depends of what engine you use. The most widespread MTS theme engine out there, is KTE (Kameks Theme Engine).
However, its last version available by the time of this writting, only suppports MTS version 1.0 and 1.1. This theme
is written to fit version 1.3. KTE will not allow you to load themes with MTS version highter then 1.1. So, I will
explain how to load it on MTS loader v1.65, which is the MTS engine that I used while writting this theme:

 1 - Open up MTS loader main dialog. You can use the /mts command to do this;
 2 - Select menu "File > Add";
 3 - Go all the way to this theme path and select Anaconda.mts file. It will appear at the themes list on the main dialog;
 4 - Select this theme from the list and click "load".

If you are using any other engine thats not MTS loader, check out its documentation to know how to load a theme; if you 
don't know what an MTS theme or MTS engine is, you might not understand what these files are all about, and its beyond
of this readme.txt file to explain in detail what all of this crap means. Check out http://www.mircscripts.org/mts.php
if you want more information about MTS themes for mIRC or want to know what that is.

Note: since this theme was written using MTS loader to test it, it is safe to say it will work best in that engine.
      It doesn't imply the engine to be the best, or even a good one, though.

Contact:

liquidsnake@sapo.pt

Credits:

Anaconda.mts, Anaconda.mrc, Anaconda2.jpg, and status.jpg by Snake;
chan.jpg by viper club of america (the original picture), modification by Snake;
Anaconda.jpg by Columbia TriStar Home Entertainment;
As for the rest of the images, I just found them at Kazaa. I don't know who are their authors. If you happen to be
the author of any of them, or you know someone who is, please email me at liquidsnake@sapo.pt so I can give them
their earned credits.
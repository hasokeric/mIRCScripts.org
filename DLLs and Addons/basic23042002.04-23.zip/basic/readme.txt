Basic v23042002
by blue-elf (belf@mircscripter.com)
Released on 23rd April, 2002

About		Basic is a script for mIRC 6.01.
		Scripted in WindowsXP.

Installation	Extract all the files in a directory. If using WinZip,
		check the option "Use folder names".

		Copy mirc.exe into the main directory and that's it.

		Make sure mirc.exe is in the same folder as the mirc.ini.

Old Users	If you've used Basic before, DO NOT extract this over the
		old version. This is a completely different set of files, etc.
		
		I'm sorry, but you'll have to re-add your userlists and other
		settings again.

Requirements	mIRC 6.01 and some experience with scripts and Windows.

Bugs, comments	Contact me.
		And also, PLEASE READ THE CHANGES.TXT to see what's new.

Donations	Ask me for a mailing address. Heh.

-end-

                ####################################
		 Spyder AntiSpam v1.07 - 21/12/2004
                ####################################



	To load press ALT+R > File > Load ; browse the 
        Spyder AntiSpam folder and doubleclick on antispam.mrc

	Click "Yes" for initialization commands.

	For more information click on the Help menu in the dialog box.


	Merry Christmas and Happy New Year!



	Hage Yaapa 
	spyderwares@yahoo.com
	

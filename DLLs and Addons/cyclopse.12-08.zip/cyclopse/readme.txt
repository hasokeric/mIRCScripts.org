//////////////////////////////////////
//                                  // 
// Cyclopse 1.0 for MTS 1.1         //             
// � by [JH]                        //
// Remember, ripping is for lamers! //                       
// Email: jamhar@gmail.com          // 
// MSN: djamz11@hotmail.com         //
//                                  //
//////////////////////////////////////

Installation notes:

- Download the .zip .
- Extract the folder (cyclopse) to your irc directory themes folder, for example C:\program files\irc client name\themes .
- Run your IRC client .
- Open the MTS or KTE theme engine and apply Cyclopse.mts .
- After applying it is advised you restart your client as all the old theme colours will still be there .

Help notes:

- Please email me at jamhar@gmail.com for help .
- Contact me on IRC at irc.nws-irc.co.uk #Goa-IRC .
- MSN djamz11@hotmail.com .
- Visit website and post in forum at www.Goa-IRC.co.uk

Update notes:

- 27/08/04 Added image to status window.
- 16/10/04 Fixed additional red/blue colours added.
- 17/10/04 Changed timestamp with another bracket on either side.
- 21/11/04 Changed "was kicked by" to "was booted by".
- 22/11/04 Added swear/abusive words to invite only, banned, full messages when attempting to join a channel.

###################
#                 #
#    HAVE FUN!    #
#                 #
###################
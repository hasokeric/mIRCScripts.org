5.2k5

hi. in here, in the toplevel folder is where you put a copy of mirc. the .exe is all
you need to use changes, and changes is all you need for irc. if you dont understand
what that means, ask someone. once you run the script, itll ask you for a few pieces
of information such as the nicks you usually use, and then youre ready to go. use
mirc 6.12 or later, or strange things may happen. during setup, changes will run the
help for you to read. you can leave it sitting there and refer to it as you go, and
you can type /help to bring it up at any time to see what this command does, what that
popup is for, and so on. this script has been around in one form or another since 96,
it has everything you need, and nothing you dont. if you dont agree, it means you dont
know what youre talking about, simple as that. legal/merchantability disclaimers are
in the help, for those of you using this script while in a business/commercial setting.
thanks for trying changes, it takes a while to see everything there is to see.. after
a few days or whatever, mail sraenn@yahoo.com and tell me what you think. if you have
something earth-shattering you need to communicate, you can find me on efnet using the
nick phalse, usually not leareth.. tho i dont irc much anymore. try asking for Crys in
project entropia =D hope youve found whatever youre looking for..

incidentally, a few ppl have asked me why i havent been on irc in a while.. the following
is one reason why.. =D

[@Granger  ] download the latest driver for your graphics card
[@Granger  ] if that doesn't work
[@Granger  ] install with a slipstreamed version of XP Sp2
[ phalse   ] so far I've got no probs with sp2
[ phalse   ] if I do, I'm unaware of it
[@Granger  ] and then install the newest version of the ATI drivers
[ phalse   ] though I've tweaked my machine to the furthest degree
[@Granger  ] ?? tweakers
[@CyberGeek] tweakers == <not Defined>
[@Granger  ] ?? tweaks
[@CyberGeek] tweaks == If you tweaked your copy of Windows XP you're responsible for any fuckups those tweaks 
  may cause. In other words, no one is obliged to help you in here if you've tweaked your system. We have 
  enough problems with ?? pebkac users as it is.
[ phalse   ] pebkac?
[@Granger  ] ?? pebkac
[@CyberGeek] pebkac == Problem Exists Between Keyboard and Chair - i.e. STUPID user. | see ?? IQ
[ phalse   ] hahahaha
[ phalse   ] yep, more than enuf of those on efnet hahahaha
: Granger has nothing against people not familiar with the intricacies of XP
* ..join:12.23a masseym:~masseym@cdm-66-76-224-51.tyrd.cox-internet.com
[@Granger  ] as long as you're willing to learn
[ phalse   ] I don't consider this a very deep or complex os
[@Granger  ] if you have that attitude you're not gonna last in here
[@Granger  ] so I suggest you drop it
[ phalse   ] fs's within partitions within slices etcetc on fbsd, now that's a bitch =]
[@Granger  ] ?? stfu
[@CyberGeek] stfu == SHUT THE FUCK UP | How about a nice cup of STFU!!! > http://www.idiots-guide.org/stfu.htm 
  | http://www.stfu.se/ | http://www.steadyflow.net/pictures/stfu.jpg
[ phalse   ] Granger.. I love you too. you really should be less nazi-esque.
[@Granger  ] XP is just as complex as any version of *nix
[ phalse   ] uh oh, a zealot
[@Granger  ] no I use linux at home
[@Granger  ] as well as XP
[ phalse   ] oh
[ phalse   ] which linux distro do you use
[@Granger  ] anyone that says that 1a 1.25gb installed base os isn't complex is an idiot
[@Granger  ] phalse: debian Sarge
[ phalse   ] production server os for a desktop.
[@Granger  ] both
[@Granger  ] �
[ phalse   ] whatever tho, I'm probably gonna do same with fbsd 5.3release
[ phalse   ] learning it lately
[@Granger  ] when you get down to the level of tweaking the equivalent of the linux /etc dir in windows
[@Granger  ] you can talk
[ phalse   ] so far the combination of ports and packages is pretty sweet, I like the flexibility of the 
  differences between them
[@Granger  ] if you can't do that don't say that windows is *simple*
[@Granger  ] mandrake and redhat try to implement windows like ease of use
[+Oversight] ports and packages, you must be using gentoo or debian
[@Granger  ] and they're just as bloated as their windows counterpart
[ phalse   ] OVERKILL.. scroll up, fbsd.
[ phalse   ] oversight, see above
[ phalse   ] stupid script =]
[+Oversight] ah, BSD. pssh.
[@Granger  ] freeBSD has a portage like system
[ phalse   ] I gotta rewrite my shit to make it context sensitive with respect to time
[+roto     ] portage like system?
[+roto     ] haha, no. gentoo has a port's like system
[@Granger  ] package system similar to portage
[@Granger  ] :P
[@Granger  ] so I'm sleepy
[+roto     ] get your timelines straight, hacker!
[@Granger  ] ya I know
[+Oversight] yeah gentoo is basically a linux clone of freebsd
[@Granger  ] portage is impired from fbsd ports
[ phalse   ] anyone ever set the mft reserve space setting to max in xp pro?
[ phalse   ] and if so
[ phalse   ] did it make thinks like tmp files and defragging take all year?
[ phalse   ] I'm thinking about increasing mine a bit
[@Granger  ] ?? tweaks again
[ phalse   ] uh
[@CyberGeek] tweaks == If you tweaked your copy of Windows XP you're responsible for any fuckups those tweaks 
  may cause. In other words, no one is obliged to help you in here if you've tweaked your system. We have 
  enough problems with ?? pebkac users as it is.
[ phalse   ] thinks=things
[ phalse   ] pebkac hahaha
[ phalse   ] jono.. wtf do you idle here for?
[ phalse   ] =]
[@Granger  ] phalse: watch it
[@Granger  ] if you wanna tweak the hell out of this OS
[@Granger  ] it's fine by me
[ phalse   ] I already have
[@Granger  ] but don't be a smartmouth about it
[@Granger  ] and don't pick on people who idle here
[ phalse   ] I've wrung blood from this miserable rolling car crash
[ phalse   ] I know jono
[ phalse   ] for only about a million years now
[ phalse   ] the martial thing is getting old
[ phalse   ] you can quit swinging yer dick around just cuz the chan is kinda slow right now
[@Granger  ] this conversation is getting old
* Granger kicked you from #windowsxp (excuse me?)
* Topic set by Granger at 6.09p 12/7: #WindowsXP Support | No Lameness/Warez/Msg/Triggers/Scripts/Colors | 
  Pre-Christmas Shopping Time
* #windowsxp synched, 140:0.541s ..o-32:22.85% ..n-108:77.14%
[ phalse   ] irc doesn't permit stuttering, you heard what I said
[ phalse   ] unless you need to reload your vid driver or something
[ phalse   ] so turn it down a thousand, kick back with a beer or something.
* ..chan:12.32a ..modechange by Granger: +b *!*@secure.shell.la
* [Granger] kicked you from #windowsxp (out)
* Unable to join #windowsxp: banned, waiting for banlist..
* #windowsxp has ban "*!*@secure.shell.la" by Granger
[-Granger] took you that long? dude you're a stooge =] but ever need any help with tweaking, I'm the prince 
  of tweak, you know my nick. p'z =]

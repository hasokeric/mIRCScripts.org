
	* mIRCDrop (CSB: v1.1b/w32/m5.9) *

                        Author: S_C_A_R


	1. Important!
	2. About
	3. Commands
	4. Contact 

1) - Important ! -

     * The bot automatically ignored: ctcps, invites, notices on start (protection)
     * Rightclick anywhere for bot options
     * When users quits they will need to re-identify when they return
     * If you are identified as Admin and quit you do NOT have to re-identify when you        return, however if the bot quits while you are identified as Admin you WILL           need to re-identify.
     * Administrators may use Regular users commands like: AOP #chan add/del etc..

2) - About - What can this thing do?

 I decided to build this bot because i wanted something that was stable, being a DALnet user i know how shit DAL services are, always laggy or down. With this bot i can get ops in channels i have AOP if services are down, and much more. CSB does not have the annoying 'Auto Talk' or the lame ! commands or the ever so lame 'Bar'. It's a simple and practical bot designed to help you run your channel. If you don't like it, and you want a bot with the pretty pink n purple colors, then don't use it, and don't complain. Comments, other than 'This sucks' or 'This is lame', are welcome ;P

 CSB (Channel Service Bot) was designed to basicly act as a combination between NickServ and ChanServ. Users may use this bot as a protection/service bot for their channel. The bot administrator may add users to the Bot's access list. Once a user is added, they can identify to the bot and register channels. If the user registers a channel with the bot, they will be able to add other nicknames to the AOP/VOP list. 

 * VOP     = Voice OP (auto voice on join)
 * AOP     = Auto OP (auto op on join)
 * FOUNDER = Founder of channel (able to add vops/aops)

 In order for a regular user to register a channel with your bot, they will beed to have a password set, and identify (See 'Commands' for command details). The person who registered the channel is automatically given FOUNDER access to the channel (Level 3). they will be automatically opped on join. FOUNDERs may only add users that have a password set to the AOP/VOP list. Please note the User with channel access will have to identify before the bot ops/voices them.

 Identified bot Administrators may remotly set bot options (See 'Commands' for further details). They can register or drop channels without having to identify to the bot.  Admins may op themselves in a channel they did not register if, of course, the bot is opped in that particular channel. They may also set modes to an unregistered or registered channel.

	* Only administrators may add/remove akicks (perm/temp). *

 The auto kick feature works basicly like a 'shitlist'. Once a mask is added to it, the bot will kick/ban anyone matching it, IF they are not identified as bot administrator. If you accidentally add a mask that matches yours, don't worry as long as you are identified, the bot will NOT kick you.

 The flood protection on the bot is also very powerful and effective. Once a flood type is triggered the bot will attempt to stop it and kick the offender and clones out. The mask that was used to flood will be added to the akick list. CSB also protects against takeover attempts such as banning *!*@* and mass deopping. Please note the Administrator will not be punished on flood.

 Flood type triggers:

	* Join Flood (single host)
	* Join Flood (multi host [proxy], *!~*@*)
	* Channel Flood (txt/action/notice/ctcp, single host [multi nicks])
	* Mass Deop
	* TakeOver (+b *!*@*)
	* Clones
        * Personal Flood Attacks (ctcp/msg/notice/dcc)

 If some lamer decides to use his 'leet' socket clones to flood your bot, CSB will automatically ignored *!*@* for 5 minutes. The bot will continue to op/voice users throughout this 5 minute period, but users/admins may not identify or change bot options.


4) - Commands -

	 * All commands to the bot must be sent to the bot via /msg nick *
	 * Parameters enclosed in [] are optional                        *
	 * Parameters enclosed in <> are requiered                       *
 
 Command                  Parameters                          Function
 -------                  ----------                          --------
 identify                 [Administrator] <password>          identify to bot
 ident                    same as above                       same as above
 login                    same as above                       same as above

 uptime                   N/A                                 display sys uptime  

 register                 <#chan>                             register chan under your
                                                              name. (Must be                                                                        identified)

 drop                     <#chan>                             drop channel                                                                          registration. (Must be
                                                              identifed and have 
                                                              FOUNDER access to chan)

 set                      passwd <new nick pass>              set new nick password   
                          <#chan> exclude <on|off> [-octdjp]  EXCLUDE ON will turn OFF 
                                                              protections for <#chan>.
                                                              EXCLUDE OFF will turn ON
                                                              protections for <#chan>.
                                                              (see below for what
                                                              -octdjp is.)                  
 op                       <#chan>                             bot ops you. AOP+
 voice                    <#chan>                             bot voices you. VOP+
 invite                   <#chan> [nick]                      Invite [nick]. VOP+. If 
                                                              [nick] is not speicifed
                                                              you are invited.   
 
 aop                      add <#chan> <nick>                  give nick aop on #chan
                          del <#chan> <nick>                  remove aop for nick

 vop                      add <#chan> <nick>                  give vop to nick
                          del <#chan> <nick>                  remove vop for nick

 addaccess                <nick> <password>                   give user access to bot
 delaccess                <nick>                              duh..

 adminset                 massflood <lines> <secs>            massflood settings
                          server <server> [port]              set default server
                          joinflood <joins> <secs>            joinflood settings
                          proxyflood <joins> <secs>           proxyflood settings
                          channelflood <lines> <secs>         chanflood settings
                          clones <max clients/mask>           clone limit
                          massdeop <deops> <secs>             massdeop settings

 adminregister            <#chan> <nick>                      registers channel under
                                                              <nick>
 admindrop                <#chan>                             drop registration

 adminop                  <#chan> [nick1 nick2..etc]          op [*], if you dont 
                                                              specify [] you will be                                                                opped

 adminmode                <#chan> <mode>                      set <mode> in <#chan>

 akick                    add <mask> [reason]                 add mask to shitlist
                          del <mask>                          del mask from shitlist
                          wipe                                wipe shitlist (667 only)

 adminpass                <new admin pass>                    change admin password

 sldelete                 <level> <mask>                      delete mask from level


                         * Levels: 667 (shitlist/perm)
                                   666 (join flood/temp)
                                   665 (mdeop/temp)
                                   664 (chanflood/temp)  
                                   663 (clones/temp)   
                                   662 (takeovers/temp)

                         * -octdjp o = take over prot off
                                   c = clone prot off
                                   t = channel flood prot off
                                   d = mass deop prot off
                                   j = join flood (single/multi host) prot off
                                   p = perm auto kick off
                                       (bot will not kick akicked users in chan)
                         * any comination of the above parameters will work.
 

The following commands are for Administrators ONLY:

 * adminpass
 * adminregister
 * admindrop
 * adminmode
 * adminop
 * sdelete
 * akick
 * addaccess
 * delaccess

The following commands are for Registered and identified users ONLY:

 * register
 * set
 * drop
 * aop
 * vop
 * op
 * voice
 * invite

The following commands are for all users:

 * uptime

4) - Contact -

 * You may contact me if you wish to leave your comments or suggestions

 IRC:    irc.dal.net 6669 - chan:  #cable-mp3, #fawker
 e-mail: spellcaster32@hotmail.com
 ICQ:    44493377 (I dont go on ICQ very often)
 AOL:    I don't use crap Instant Messangers

 						Thanks and enjoy,
						S_C_A_R


[ Install ]

To install this addon
1 - Unzip the ccprot.zip into your mIRC directory.
2 - Once that's done, type /load -rs ccprot.mrc
3 - Click 'Yes' when the dialog box pops up.

Please note that this addon will only load on mIRC 6.03
www.mirc.com


[ Addon functions ]

Once you've opened the setup dialog, you'll see that everything can
easily be customized to you're preferences.
Here's what some of the functions mean...

- Display 'info' dialog: With this enable, another dialog will popup when a 
user goes over the max control code limit, and will list exactly the amount
of control codes used and what type they were.

- Enter max control codes: This is where you will enter the max number of
control codes allowed before the script will react.

- Exclude: By checking any of these boxes, the script will simply ignore a user
with that mode. For example, if you don't want to kick an OP for too many control
codes, then check the Ops box.

- Channels to operate on: Simply enter a channel name and click 'Add'. The channels
listed are the channels the addon will function for.

- Action: Under this section, you will be able to select the type of action that occurs when
a user goes above the max control code limit. (K/B is kick/ban)


[ Disclaimer ]

Under no circumstances will the author or anyone involved in the 
making of this addon be held responsible for any damage resulting 
from the use of this addon, whether emotional, physical, loss of data, 
health, wealth, religious beliefs, computer, or whatever other type of damage. 
By using this script and reading this document you agree not to hold 
the author or anyone who helped make the addon, responsible 
for (including but not limited to) above mentioned damages. If you do 
not agree with the above disclaimer, you should remove this script from 
your computer immediately.
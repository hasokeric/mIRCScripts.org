//==============================================
// Author:                  MaSOuD
// E-mail:                   Masoud@DCScript.Net
// Version:                1.7.2
// Released date:    1 May 2009
//==============================================
 // You can visit me at:
 DALnet: #DCScript - #HelpDesk - #Scripting - #Scripted

//==============================================
// How To Run:
 Just copy mIRC.exe into the Script directory and run it.
 DO NOT COPY your own 'mIRC.ini' into the mBOT directory!

//==============================================
// mIRC version:
 Please only use and copy *mIRC.exe* version 6.21 or above!

//==============================================
// mBOT Script
 It's too important, so please be careful, DO NOT MODIFY/ADD your own Scripts/Events on original Files/Scripts!
 If you would like to load an Addon onto this script please loading it by a 'New File'.

 DO NOT CHANGE THE FONTS IN THE SCRIPT, BECAUSE THE HELP FILES WILL BE SHOWN UGLY...

//==============================================
// Best View:
 The best view resolution for the DC mBOT's script is 1280x1024 pixels.

//==============================================
// Spacial Thanks To:
 (ArSiN)           He gave me some idea and helped me to writting this IRC/mIRC Bot...
 (xDaeMoN)    For "xSeen v3.9"
 (You)               For your support and Downloading/Using this script :)

//==============================================
// What's NEW?! (History)

// Version 1.7.2:
 Released date: 1-May-2009
 - Fixed a bug that does the bot to halted...
 - Changed Log reader (Now you can see all the Logs in the main dialog with colors. But DO NOT load those Logs has many lines, because it may does halt your script.)
 - Fixed some other small bugs.
---------------------------
// Version 1.7.1:
 Released date: 24-February-2009
 - Add a new !cmd to clear the Bans/Excepts/Invites list on channels. "!Cb - !Ce - !Ci"
 - Add a logging for any query message(s) has sent except of commands...
 - And a few bug fixed about Auto voice on Extra settings...
---------------------------
// Version 1.7:
 Released date: 10-January-2009
 Modified:
 - Fixed 'Badwords' protection... (It does wrong ban, it's now works fine.)
 - Fixed 'Backup' about 'Invalid parameters: $did (line 345, BackUp.mrc)"
 - The mBOT now completely works with space in the folder address... (Like: F:\New Folder\DC mBOT\...)
---------------------------
// Version 1.6:
 Released date: 26-December-2008
 Modified:
 - Fixed a little bit of codes about 'Weather' and 'Top10' (Now They are works fine...)
 - Fixed Texts/Styles in dialogs...
---------------------------
// Version 1.5.5:
 Released date: 1-December-2008
 Modified:
 - Fixed codes about Main settings Add/Del masters. (And !Amaster - !Dmaster)
 - Fixed a fault about Bantypes...
 - Fixed some help files.

 Added:
 - ASCII table help to Talk Bot.
 - Connect/Disconnect to Status options menu.

 Removed:
 - Restart request when you would to turning ON/OFF the toolbar.
 - Server history from Status options menu.

 Note: My dear "Ignore user while sent Wrong Command" checkbox in the "Main Settings" was just about the Login/Sendpass/... totally I can say it's about Passwords and Security codes.
 I wrote it for just a little security... Please don't ask me again What's it or what it does! Thanks :)
---------------------------
// Version 1.5.1:
 Released date: 25-November-2008
 Modified:
 - I forgot to edit some part of Backup dialog and now it's fine.
 - The mBOT version on "mIRC Fullname" now is correct.
---------------------------
// Version 1.5:
 Released date: 14-November-2008
 Modified:
 - Redesign the Backup dialog and added some new features.
 - Some changes in Readme Viewer.

 Added:
 - Co-Owners with "Comma". Somebody needs this feature and I did added it :)
---------------------------
// Version 1.4:
 Released date: 16-September-2008
 Added:
 - Statusbar and Settings Dialog with Statistics Announcer (Based on hOS.dll and MDX.dll)

 Modified:
 - Fixed some Help files.
 - A small change in IP Locator's about parsing output message.
 - Some small changes in the About dialog ;)
 - Fixed the *Don't Kick/Ban Ops* in the Protections and Now when you checked this option Bot never will be banned HOPs in the channels too.

 Removed:
 - EDLL.dll
---------------------------
// Version 1.3:
 Released date: 25-August-2008
 Added:
 - Talk Bot (It's almost a fun bot...)
 - Internal Help section. (F11)
 - Startup loading.
---------------------------
// Version 1.2.1: (Minor version)
 Released date: 16-August-2008

 - This is not a New Version, I just modified the old scripts and I'd fixed the small bugs...
---------------------------
// Version 1.2:
 Released date: 8-August-2008
 Modified:
 - Main Settings.
 - A little bug in the 'Daily BackUp' section.
 - And I'd totally checked scripts and fixed it all...
 - Fixed a bug in the Ban/Unban in channels auto modes.

 Added:
 - Auto Join System (Network & Auto Identify Supports)
 - Log Reader
 - IRCop Section! (Oper Login, Auto-Kill list, ...)

 Removed:
 - Google Bot.
---------------------------
// Version 1.1:
 Released date: 22-June-2008
 Modified:
 - mBOT Main Settings
 - Extra Settings
 - Toolbar

 Added:
 - xSeen System v3.9
 - !Find
 - !ChanStat
 - Co-Owner
 - Backup and Restore
---------------------------
// Version 1.0:
 Released date: May-2008

 - The first public release.

//==============================================
// DLLs Used:
 MDX.dll + (CTL_Gen.mdx & Dialog.mdx & Views.mdx & Bars.mdx)
 hOS.dll

//==============================================
// Bug and Report:
 If you have found any bug or anythings doesn't work, Please contact me via my E-mail,
 OR add a comment to wherever you have downloaded this script. 
 All suggestions are welcome :)

 This is the DC mBOT's page in the mIRCScripts.Org:
 Http://mIRCScripts.Org/comments.php?cid=4144

// Best Regards,
// The End.
//==============================================
// Thank you for using this Script and Enjoy ;)
//          DC mBOT v1.7.2 By MaSOuD
//==============================================
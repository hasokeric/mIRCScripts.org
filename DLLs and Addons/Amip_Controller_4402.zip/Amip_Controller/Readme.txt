The dll is not mine, I did not right it, nor am I responsible
for any harm that may come to your system from the use of 
Google's AMIP controller script.
You must have AMIP installed, Tested with Foobar2000

SendKeys.dll - Written By Dan 2001 *FINAL*
=========================================
Email: Dan@dan21.ukshells.co.uk

                         .'      `''''`._
                        .'               `.
                        |                 |
                        |   _  .Y---.      |
                        .,'''\ |    ``     |
                        ||   | \     `|    |
                        ||__,-'`--..__|    '.
                        | -'        `-.     |
                        .\       _.-' |     |
                        |`:.._,-'  _,Y\      \
                       .|/ `b_,,Y''    `.     `.
                      ,'.'              |       \
    /-.._           |'  |                |       `.
    \    `.        ,'  /                 \        `.     __
     `.    `.     ,/  /                   \.       |_ ,''  \'
       \     `..,Y   /'                    \.       ''    ,/
        \            /                      `|           .'
        '.          /                        |           |
         -.        /                         |          /
           `".._  |                          |     |---'
               |  |                          |      |
             ,''`.|                        ,,:..__ _i,b
       ,.Y-''      \                      .'     ''    `.
      |'            `.                    |             |
      /               \                   |             ' .
     .'                \                _.'                `.
     |                  `.            ,'  |                 |
     |                   \`._      _,'    |               ,Y'
     `.                   `. `'''''       |             ,'
       `-.                 |    ________  |         _.-'
          `'''-..__   _,,Y'|`'''        `.|     ,-''
                   `''                    `'''''drevele2002

Yet another theme release... ok my second.
This time the theme dosent TOTALY suck!
its kida linux like i guess takes a little bit to figure it out but well
after that your r0xin!

___________________________________________________________________
Theme: cIRC
Schemes:
	Default [dark colored eazy on the eyes no time stamp]
	Dark Timestamp [dark colored eazy on the eyes w/ time stamp]
	Lite [wite colored kida feels weird on the eyes no time stamp]
	Lite Timestamp [wite colored kida feels weird on the eyes w/ time stamp]
Version: 1.0
Coder: DrEvele
Tested On:
	mIRC 6.03 w/ Eric^^'s MTE Version 3.3
	mIRC 6.03 w/ KTE Version 1.5
Works Best With: MTE
Website: http://www.jeffsworld.net/
Email: JeffJohnson@ZoomInternet.net
Deployed With: 
	K MTS Theme Editor v0.71
	Textpad
MTS Version: 1.1
___________________________________________________________________
(c) 2002 jeff johnson /server iam.jeffsworld.net

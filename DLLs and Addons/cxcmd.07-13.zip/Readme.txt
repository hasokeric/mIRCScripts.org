##########Complete X-Commands v2.0##########
############################################
## Complete X-Commands v2.0 by |Red_Bu||  ##
## Created: July 2003                     ## 
## Copyrighted � 2001 -2003 |Red_Bu||     ## 
## Email: ole@team-future.com             ## 
## DO NOT CHANGE/REMOvE ANYTHING BELOW!!  ## 
############################################ 
############################################


Thank You For Downloading And Using This Addon!


=>Information<=
I would like to thank You for downloading and using this addon. 
This addon will make it easier for Undernet users and such, (networks with the X Bot) to run commands on X. 
The only thing you would have to do is press the buttons (the button which contain the command you want done) and fill out the rest you may be asked about.
This script was scripted from The X-Commands document from the Cservice site, Last updated 11.04 - 2002 by ReD_IcE.
I hope this script will make it easier for you. Feedbacks are welcome!


=>Version History<=

Complete X-Commands v2.0:
=========================
* Removed the KillerScriptet icon
* Made the Help dialog
* Fixed some small bugs
-------------------------

Complete X-Commands v1.0:
=========================
* First Public Release
-------------------------


=>Installing the addon<=
To install this addon do this:

1. Open the zip file, Extraxt the Cxcmd folder into your mIRC directory.
2. Open your mIRC.exe file
3. Write this in the status window: /load -rs Cxcmd\Cxcmd.mrc (but remember if you have
   extracted the Cxcmd\Cxcmd.mrc folder into another folder like system, in your mIRC directory,
   you must write this: /load -rs system\Cxcmd\Cxcmd.mrc and so on if you got more folders..

Now the Cxcmd.mrc addon should be installed and ready to be launched!
if you still got problems email me!


=>Disclamer<=
The KillerScript's is provided without warranty of any kind. In no event shall The KillerScript's Author
be liable for any damages whatsoever caused by the script's any related files, 
even if KillerSciptet's Author has been advised of the possibility of such damages. 
KillerScriptet may not be distributed as a part of any commercial package. 
All rights of The KillerScript's are owned by the author. 
Any violations to the script's copyrights will be prosecuted by the law. 
(Rights of the external programs in the script are owned by their respective authors.)


=>Author Announcements<=
I really hope you like this addon.. if you got suggestions/questions/errors/bugs anything
be so kind and email me!
Read the Disclamer carefully, if you need more infos about it, check: http://home.no/killerscripter/Disclamer.htm
Feedback are mostly welcome!

NB: This addon is only for personal use, you are not allowed to rip it or lease it on the internet
    without the authors permission.

=> Author: |Red_Bu|| <=
=> ole@team-future.com <=
=> www.killerscriptet.cjb.net <=
=> find me @ undernet servers <=
=> channels: #Burnout <=
=> ALL RIGHTS RESERVED <=
=> Copyrighted � 2001-2003 |Red_Bu|| <=


  *******************************************
 **                                         		      	**
 **  Magick^ControlPanel - by Tanthalas (c) 2003  	**
 **       http://www.magick-knight.com    	        	**
 **                                           			**
 **      The world is a magickal place....        		**
 **                                               		**
  *******************************************

This addon for mIRC 6.03, takes the contents of an ini file, and uses that information, to create an MDX'ed control panel dynamically, without having to hard code any of the options etc. This means, that for those of you who update your scripts with new features etc, updating your control panel, is as simple as modifying a single .ini file, include an xtra icon, and of course the new features you have written :)

The syntax for the control panel ini file is very rigid, and that is the only work you need to do, apart, from unzipping all the files to a folder in your mIRC... All icons, cpanel.ini, and this file should be in the same folder. Icons with spaces in the file path or name are not an issue, as $shortfn() is used to prevent this. (Yes Matrix-- i found where the problem was, i put the $shortfn in the wrong place, on 2 lines. Now I have FIXED IT)

Feel free to use this, but please give credit where it is due.
Now, I know that some people will say, that you can start with 0, in your ini, thats true, i just didnt feel like it.. If you want to use 0, drop all the $gettok references by 1....

Here is the layout, for your ini file.
file: cpanel.ini

 [cpanel]
 1=path\to\first\icon.ico�Description of Option�Alias Command
 2=path\to\second\icon.ico�Description Number 2�Next Alias

One note, � is easy to produce, hold down ALT, and then on the numeric keypad, hit 0 2 2 2 then let go of the ALT key :)  as you can see, its very straight forward, and when the cpanel.ini is saved, you have a good, working control panel

To open the control panel, type /cpanel from the command prompt, or set up thru your popups :)

(c) 2003 Tanthalas. http://www.magick-knight.com
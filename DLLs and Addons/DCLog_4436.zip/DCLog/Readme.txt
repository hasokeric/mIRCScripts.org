// ================================================== \\
\\ Author:          MaSOuD                            //
// E-mail:          Masoud.1984@Gmail.com             \\
\\ Website:         Http://DCScript.PersianGig.com/   //
// Version:         2.1                               \\
\\ Released date:   Saturday, 09 July 2010            //
// ================================================== \\
\\ mIRC version:

 I've written this addon by mIRC v6.35.
 You may use it with another version of mIRC but there is no guarantee about that it does work corrently/exactly...

// ================================================== \\
\\                    How To Run                      //

 Unzip the "DCLog.zip" copy it into the your mIRC directory and use this command in your mIRC: //load -rs $+($shortfn($mircdir),DCLog\DCLog.mrc)
   OR
 Copy it to directory and on the mIRC Script press Alt+R, click on "File" Menu from its Menubar and click on "Load" find the "DCLog.mrc" and load it.

 After load the addon you can run it by clicking on Menubar or Right-click on 'Status|Channels|Nicklist' or type: /DCLogs

// ================================================== \\
\\                 About This Addon                   //

 By using this addon you can read your log files almost exactly like a real chat/channel window with colors. (If you haven't checked the 'Strip codes' in mIRC options)
 Beside this, you can search for filenames in your log directory OR search for a 'Search key' in entire log files!

// ================================================== \\
\\                     Change Logs                    //

 v2.1 (Saturday, 09 July 2010):
  - Fixed the miss-type in the OnLoad event. (It was '/DCLog' but the correct command was '/DCLogs'.)
  - Added the 'WhileFix.dll' and it won't freeze your mIRC during the search anymore.

--------

 v2.0f (Monday, 14 June 2010):
  - Added a Log Viewer for it beside of Log Seacher.
  - It doesn't use $read anymore, I've written the new version with File Stream/Handler and now it's so much faster :)
  - More improvement in aliases and dialog.

// ================================================== \\
\\                     DLLs Used                      //

 MDX.dll + (Dialog.mdx & Bars.mdx)
 WhileFix.dll

// ================================================== \\
\\                   How to find me                   //

 You can visit me at these IRC Networks: (My nickname is 'MaSOuD' in everywhere I am.)
	1) BeDeHi.com:	#DCScript - #BeDeHi - #Help
	2) DAL.net:		#DCScript - #HelpDesk - #Scripting - #Scripted - #Scripts
	3) UnderNet.org:	#mIRCScripting  - #Scripted - #HelpDesk - #mSL

// ================================================== \\
\\                  Bug and Report                    //

 If you have found any kind of bugs and/or Errors or anythings doesn't work, (Or doesn't work right...)
 Please contact me or visit: Http://DCScript.PersianGig.com/support.html
 All suggestion and/or fustigation are welcome :)

// ================================================== \\
\\                    Copyright                       //

 There are no copyrights for this bot. BUT:
 You know, Developer/Coders/Scripters are working so hard on their projects (Not only in mIRC, in any kind of plateforms) to let you using a/an better/advanced environments.
 So, if you've got some conscience, then do not rape this and/or any kind of other Projects/Scripts/Addons/... :)

// ================================================== \\
//                Best Regards, E.O.F.                //
\\ ================================================== \\
Airplane 3 - By Foshizzle 
copyright 2008 PicWin Studios
--
Readme
--

Airplane 3 is the third in the series and has better media(graphics/music), fullscreen capabilities, and much more!

to use, unpack files and load into mIRC(in remotes click load, find the file, and voila! - type /load -rs "path to script\Airplane3.mrc" in the edit box) - there is no need to put the files into the mIRC directory
then, type /airplane3 to run
to run in fullscreen type /airplane3 fs
or
right click anywhere and select airplane 3 > full screen / windowed
click play and you'll be on your way!
use the arrow keys to move the plane, and space bar to shoot

the objective of the game is to shoot down as many planes as you can, collect powerups, and get as many points as you can

=====================================
      DC Winamp Controller v1.1
=====================================
 Author:	MaSOuD
 E-mail:	Masoud.1984@Gmail.com
 Release date:	Feb 23 2012
 Website:	Http://DeadCeLL.eu5.org/
=====================================
* How To Run:

- First Unzip "DCAmp.zip" copy it into the your mIRC directory

- Use this cmd: /load -rs C:\mIRC\DCAmp\DCAmp.mrc (Replace Your 'mIRC Path' to address)

   OR

- In the mIRC Script press Alt+R, click on "File" Menu from its Menubar and click on "Load" find the "DCAmp.mrc" and open it.

After loading the addon you can run it by clicking on Menubar or Right-click on Status, Channels or type: /DCAmp
=====================================
* About This Addon:

- You can control the Winamp from your mIRC Toolbar. In Settings there's an Announcer option,
it's up to you whether use it or not.

- Winamp Toolbar NOTE: It works with the original mIRC's toolbar, if you have any custom
toolbar it won't work... (Or you can modify it and add these items to your own Toolbar.)
=====================================
* Bug And Report:

- If you find any Bug or something doesn't works, contact Me with My E-mail address or leave
a comment wherever You download this addon. Thanks.

- All suggestions are welcome :)
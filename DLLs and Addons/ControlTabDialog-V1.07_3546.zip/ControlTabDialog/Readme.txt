This DLL and script will add a control-tab manager.

The DLL provides the hooks and signals needed and the
script that is provided provides a basic control-tab manager.

Note: The source is available as part of the mIRC SDK being
	developed at mIRC-DLL.com

To install
==========
1. extract into your mIRC folder
2. Type //load -rs ControlTabDialog\ControlTab.mrc


Naquada
AFX
Written by [AFX]
Readme Information
 
 
1. INSTALLATION
 
To use AFX, you need at least mIRC 6.16. If you do not have at least this version, obtain the latest version of mIRC from www.mIRC.co.uk.
 
- Open the ZIP file containing the script
- Extract the files somewhere on your hard drive
- Once completed, take a blank copy of mIRC.exe and copy it into the directory  where you extracted AFX Lite
- Run mIRC.exe from the scripts' folder. The script should start up and a   small greeting should pop up
- Connect to an IRC server :)

Oh, one more thing. The MP3 player uses FMOD.dll, so you will need a decent computer, otherwise you will experience some hardcore lag (with the visuals).
 
 
2. AFX FEATURES
 
AFX has a few IRC features that can be useful to a modern IRC'er. It comes with the following:
 
- Script Configuration 
- Channel Stuff
- Download Manager
- Log Viewer
- MP3 Player (fMod)
- Nick Mentions
- Seen System
- MTS Themes 
- XDCC Server
 
In addition, some Display modules have been added. These are the Toolbar and the Switchbar. The Switchbar can be used on any four sides of mIRC, and the Toolbar is very functional. It comes with a Start button you may use, as well as the MP3 Player. Both of these features can be disabled. Hopefully, this script is useful to the user in a way where they feel comfortable with it. This is not a really big script.
 
 
3. VERSION HISTORY

v3.0

- fixed the update system where it would output 9 lines of messages
- fixed the log viewers clean logdir tool where it wouldnt work on startup when set to clear the directory on Startup
- changed adding a network to the Networks list in the config from $$?'s to a dialog where you add everything instead
- fixed the switchbar where if a user changed their nickname, you couldnt click on their nickname unless the switchbar updates (usually through clicking another button)
- got rid of Gartoon icons
- added a Nick Completor addon
- added sIRC and blink themes
- added statusbar and got rid of sZ.dll and SwBPos.dll since hOS.dll does everything sZ.dll does (it even docks)
- fixed the playlist resize bug where it wouldn't resize proper
- added a popup for the XDCC server on the nicklist for XDCC-related functions


v2.4.2

- no big changes, just changed the first time startup dialog. also, I had fixed some bugs below after I released 2.4.1, so this also ties in with below


v2.4.1

- fixed a bug with the closeafx dialog not working correct if your not connected to any servers
- fixed a bug with backup/restoring
- fixed a bug where the munzip alias was local only, and the auto update wouldn't unzip the script

 
v2.4

- fixed a good majority of bugs, and now is released publicly everywhere
- completed Channel Stuff addon
- finished help file
- fixed a huge bug with the Channel Stuff addon


v2.3

- fixed switchbar positioning bug
- added updater, now works with timer option
- started work on a channel stuff addon, but remains incomplete
- some mp3 stuff
- new setup style-menu
- new first-time use dialog
- nick mention popup goes to the bottom right of mIRC now
- undernet and quakenet are now supported in auto auth


v2.2

- fixed some MP3 Player bugs
- redid the Config menu
- started working on help file
- made the handlebar option on the toolbar optional to the user
- fixed a bug with the XDCC Server not checking the queue list 
- added 10k MP3 iconset
- did a bunch of other shit but i forget

v2.1

- fixed some bugs
- created Download Manager
- working on other things for the script

v2.0ab9
 
- first beta release

 
 
 
You may contact me via e-mail at zakafx@gmail.com, or visit my personal website (www.coderscore.org/afx)

Do not add me to MSN for script help, I have other things to be doing.
 


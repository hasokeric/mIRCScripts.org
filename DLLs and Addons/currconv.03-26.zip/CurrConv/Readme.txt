Currency Converter 1.1 by refuge & Hjorten.


-----------------------------------------------------------
 Installation
-----------------------------------------------------------
Extract all files into your mIRC directory, for example:
c:\program files\mIRC\CurrConv.

To load the script type
/load -rs CurrConv/CurrConv.mrc or load it through the
script editor in mIRC.

If curr_data.txt is not in the same directory as
currconv.mrc the script will not work.


-----------------------------------------------------------
 Removal
-----------------------------------------------------------
Type /unload -rs CurrConv/CurrConv.mrc or remove it through
mIRC's script editor.


-----------------------------------------------------------
 Usage
-----------------------------------------------------------
When the script has been loaded type /currconv to bring up
the dialog. There are now two textboxes, two lists and
three buttons. First thing you need to do is to type the
amount you wish to convert, then you choose from which
currency and last you choose which currency to convert it
to.

When you're done with that you just click "Convert" and the
script will gather the information and return it in the
textbox below the two listboxes.

If you want you can copy the result by clicking on "Copy".

Important note:
The script might tell you that it couldn't gather any info
on the currency, we have no idea what causes this, it's
probably some kind of serverside issue. When you get this
message just wait a while and try again.


-----------------------------------------------------------
 News
-----------------------------------------------------------
v 1.1 - 2004-03-25
There was a bug in the previous version but I fixed that
before the script was widely spread. In this version I've
removed currencies who are obsolete due to the EMU.

I've also fixed it to where you have to select from/to
currencies in order to complete the conversion.

Some people wanted an easier way to access the dialog so I
added a function that allows you to choose if you want a
popup in the channel window or not, it will appear as
"Currency".


v 1.0 - 2004-03-24
First public release, shouldn't be any bugs.


-----------------------------------------------------------
 Info and greets
-----------------------------------------------------------
Original idea, dialog design and main coding by Hjorten.
Socket coding by refuge. Thanks to czm, jkw and VaCiLe who
tested the script and commented it before anyone else.


-----------------------------------------------------------
 Contact and such
-----------------------------------------------------------
You can find us on the c0la network (irc.c0la.net), just do
a /whois on either Hjorten or refuge and there we are. You
can also find other scripts by Hjorten on www.ful.nu/script


EOF
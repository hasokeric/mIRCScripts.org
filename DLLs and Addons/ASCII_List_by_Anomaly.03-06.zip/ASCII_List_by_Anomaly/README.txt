::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::ASCII;List;created;by;Anomaly;::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-To load this in mIRC, just go to the Tools menu then click Scripts Editor(may be Remotes depending on the version).  
-On this dialog go to File then click Load.
-Look in the directory where you put the file(look for aschar), click the file, and click open. =)

***The dialog is accessable by right clicking on the screen or going in the commands menu***
----------------------------------------
 > Badword Filter v1.0
 > By Jake
 > jake78@bellsouth.net
----------------------------------------


[ Table of Contacts ]
  I. Introduction
 II. Installation
III. Usage
 IV. Contact
  V. Changelog


----------------------------------------
I. Introduction
----------------------------------------
Well, it's really quite simple. Instead of adding a whole bunch of on TEXT remotes with a whole lot of options, I decided that this script would be a much better alternative. So I put together the original version around December 11th, 2002, and published it the next day. The code is entirely my own, it's not especially complex, but it is effective. I honestly don't care if you use any of my code to your scripts, but please give credit where credit is due, that's all I ask.

----------------------------------------
II. Installation
----------------------------------------
Unzip badword.mrc and mircscripts.jpg to the directory mIRC is in (or anywhere else, if you know what you're doing). Make sure both files are in the same directory, open up mIRC (6.0 or higher) and type "/load -rs badword.mrc". If the scripts load correctly, it will tell you so. From there, type /badwords and the rest should be self-explanatory.

----------------------------------------
III. Usage
----------------------------------------
As of now, you cannot include badwords that have spaces. That's something I'll deal with at a later date. Also, if you are not using mIRC 6.03, the input boxes (ok/yes/no/cancel) will not display their icons correctly. This is a minor detail and affects the actual script in no way, but I suppose it could be a minor annoyance to some. Those are the only bugs I know of, if you find anymore let me know about it. As for running the script, simply add new words and edit them  using the provided dialog. Most everything in the script should be fairly obvious, but once again if you find any bugs  please let me know so I can take care of them.

----------------------------------------
IV. Contact
----------------------------------------
I'm always available at jake78@bellsouth.net, but I don't want to give out my email address. If you would like to reach me via IRC, I can usually be found on irc.gamesnet.net in #fluxynet. Failing that, leave me a message on mircscripts.org, and I'll get to that sooner or later,

----------------------------------------
V. Changelog
----------------------------------------

12/11/2002
> Start of changelog :)
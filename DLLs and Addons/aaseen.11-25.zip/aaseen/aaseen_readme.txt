::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Name ::      Seen system v.1.1
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Author ::    uzklydelis (uzklydelis@mail.com) @ Aitvaras NET irc.data.lt
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Loading ::   Extract file aaSeen.zip to your mirc directory ant type::
             //load -rs $finfile($mircdir,aaseen.mrc,1)
             or
             //load -rs <path to file>\aaseen.mrc
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Usage ::     /+seen or Seen system in MenuBar
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Storage ::   Seen system stores information about nicks in hash tables.
             So when it is saved, there will be file "aaseen.htb" ir mirc dir.
             It stores information individualy for one channel, for egzample:
             if it stores information on #mirc and #seen and if somebody types
             !seen nick in #seen, it will only lookup information on #seen,
             even if nick is or was on #mirc.
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Help ::    
 Channels :: Add channels on which you want to store seen information.
             On removing channel from list you will be asked to clear seen
             history for this channel, click yes to clear, or no to leave it.
             :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 Options ::  For seen choose prefix, sending information type and set ignore
             time in seconds that system not flood itself, when !seen is used
             frequently.
             :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 History ::  Check "auto clear history older than::" to clear history
             periodicaly automatic and choose prescription time between 5days,
             2weeks or 4weeks. You can clear history manual if you want.
             Set delay time in minutes to set how often history should be
             cleared automaticaly.
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Updates ::
 v.1.1 ::
  Fixed ::   Not checking if hash table exists and returning error
  Added ::   /hfree aaseen table when script is disabled
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
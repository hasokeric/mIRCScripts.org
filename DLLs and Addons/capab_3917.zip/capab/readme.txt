### CAPAB Addon v2.0 for mIRC
### Written by KIA (#script @ irc.gamesurge.net)
### io.dll written by Saturn
### Sep 10, 2007

#Contents

#1.	What this script supports
#2.	What does this addon do?
#3.	Using the script
#3.1.	Loading and starting
#3.2.	Commands
#3.3.	Advanced usage
#4.	Bugs/suggestions/comments
#5.	Version history

#1.	What this script supports

  This addon is intended for 
	� mIRC version 6.14-6.3 - Note that the dll used in this script is very 
	  complicated and may need to be updated for new versions of mIRC
	� Networks supporting CAPAB IDENTIFY-MSG commands - Mainly the freenode 
	  IRC network (irc.freenode.net).  In most cases, this script will not 
	  affect other networks.
  For support on this script, or for comments/suggestions, plese visit #script
  on irc.gamesurge.net 


#2.	What does this addon do?

	On the Freenode IRC network (and possibly others networks that support it,
  I'm not sure), you can enable CAPAB.  What this does is prefixes all messages
  sent by users with either a + if they are identified with netowrk services, or
  a - if they are not.  This allows you to easily see if somebody is identified
  as they are talking.  

  The boring, technical details:

	It may not sound like there is much that a script needs to do to support
  this protocol.  Anybody can type the single raw command,
	"/raw CAPAB IDENTIFY-MSG" 
  to enable the protocol.  However, mIRC is not designed to handle the prefixed
  messages.  Emotes, as they are really a special case of a regular private
  message, do not show up as private messages, and will show up as gibberish.
  In this case, other people's emotes will not trigger ACTION events, but will
  trigger TEXT events.  All scripts that you may have would no longer work as
  the beginning of each received line would be prefixed with either a + or -.  
	That is where this addon comes in.  After CAPAB is enabled, this script
  tricks mIRC into thinking that the +/- prefixes are not there, allowing it to
  trigger events and display on the screen properly.  So what is the point of 
  all of this then if we're getting rid of the prefixes?  This script then 
  changes the format of all messages seen on servers with CAPAB enabled, so
  even though mIRC ignores the +/-, you still see them.  Also, this allows 
  other scripts to see if nicknames are identified (see section 3.3)
  

#3.	Using the Script

#3.1.	Loading and starting

	� Upon downloading the file, extract the files to your mIRC scripts 
	  directory.  By default, it should create a subdirectory /capab, but that
	  is not neccessary. 
	� In mIRC, type "/load -rs capab/capab.mrc" to load the script (if you did
	  not use the capab subdirectory, modify the path accordingly).  mIRC will
	  tell you that there are commands the script needs to run to start the 
	  script.  This is fine, and should be allowed.  The script should now be
	  loaded, and will display some text in your status window.
	� By default, the script is turned ON when loaded, but needs to be started 
 	  manually the first time for servers you wish to use it on.  After
	  loading the script, follow the onscreen instructions to enable the
	  script.

#3.2.	Commands
	
	The script has the following commands
		/capab         - Shows a mini-help with the rest of the commands
		/capab on      - Attempts to turn on CAPAB for the current server.
				     This will override the default settings.
		/capab enable  - This will only change the default settings for the
				     script.  It will NOT turn on CAPAB.
		/capab disable - This will only disable the default settings for the
				     script.  It will NOT turn off CAPAB.

		Note: The only way to turn off CAPAB once it has been turned off is
		 	to disable CAPAB by default, and then *reconnect* to the 
			server.  
	

#3.3.	Advanced Usage
	
	� /msg, /me, /describe commands 
		The addon comes with /msg /me and /describe aliases that replace
		mIRC's default commands.  If it is found that you already have 
		replacement commands for these, the commands that come with this 
		script will be *disabled* by default.  The purpose of these aliases
		is add your own identification status to your input.  These can be
		enabled/disabled by typing "/enable #repmsg" and "/disable #repmsg",
		respectively.

		Note: These commands assume usermode +e means you are identified
			with network services.  Future versions of this script may allow
			you to change this, though I'm not sure if there is a generic 
			method to determining your own identification status.

	� $capab.auth identifier
		There is an identifier included with this addon that allows you to
		see if the person who triggered a TEXT/ACTION/NOTICE event is
		identified with network services.  Please	note that while this may 
		be used in another type of event, it would be extremely unreliable.
	
		Usage: $capab.auth($nick)
			Returns $true if they are identified, $false if they are not
			identified, and $null if it is unknown.  The server only sends
			this information with TEXT, ACTION, and NOTICE messages, so 
			this identifier is meant to only be used by those events, and
			only with the user who triggered the event.

	� Custom themes/scripts
		If you have a custom theme or script that formats output in your own
		format, this script will NOT conflict with it.  It is suggested that
		your custom themes are loaded before capab.mrc so that your own 
		theme has priority.  
		To create/modify your own themed events to display users'
		identification status, be sure to use the $capab.auth identifier
		(explained above), and to make sure your event has higher priority
		over capab.mrc.  

	� mIRC's messaging options
		This script attempts to preserve your messaging options from the 
		options dialog.  Mode prefix settings (@nick instead of nick), nick
		coloring, line highlighting and in some cases showing events in 
		the active window, are preserved.  Please let me know if you find
		any issues with this as I tend to use mostly default formatting.


#4.	Bugs/suggestions/comments
	
	If you find any bugs or have any suggestions, please either submit a
	comment on a download site where this addon was uploaded by me (KIA), or
	connect to irc.gamesurge.net and look for me in #script.  


#5.	Version information

2.0	Oct 10, 2007 - Complete rewrite of the script to work with io.dll in order
	to maximize mIRC's handling of the CAPAB protocol.

1.0	Sep 09, 2007 - Original version of the script.  Very buggy due to the
	nature of the protocol
BorgIRC 2.2 for mIRC
--------------------

GENERAL INFORMATION

Name: BorgIRC 
Author: STING
BorgIRC website: http://www.borgirc.net, in case of failure: http://borgirc.cjb.net

GETTING STARTED

You can start BorgIRC by clicking on the BorgIRC icon on your desktop or in your start menu.

VERSION HISTORY

Can be found in the BorgIRC menu > Script info > View What's new

DISCLAIMER

The English popups weren't made by me, but by various artists. Biggest part of the popups come from Boo's Popups 1-8
The Dutch popups are property of their respective owners.
The clone detection code also isn't my work, it was made by someone else.
The progress bar is based on the MDX dialog extensions by DragonZap.

SOFTWARE LICENSE AGREEMENT

When you start mIRC.exe in conjunction with this package, you agree to the following:

* The author of BorgIRC, STING, is in no way responsible for damage or abuse caused by the usage of BorgIRC. 
* BorgIRC is open source and can be modified at will; like I have a choice :P
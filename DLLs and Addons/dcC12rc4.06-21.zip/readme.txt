DCC Control 1.2rc4 by facts
jfacts1731@telocity.com
5/21/01

Changes:
1.2rc4 Lots of work done.  Just tell me what you think. :)
1.2 Enable Dcc Really works now.  Getting rid of messy variables.  Implementing options dialog
1.1 I have allowed for multiple dialogs now.  Enable Dcc now works, big screwup on my part.  

Introduction:

Basically I was bored today so i decided to see what i could write up.  ( I am pretty new to mircscripting. )  DCC Control is just a dialog that will popup after you recieve a dcc.  It gives you a couple of options of what to do with the file.  You can run the file, delete the file, or you copy it to an archive dir.    
  
Installation:

1. Extract the script to your mircdir. 
2. Load Mirc and type /load -rs dialogdcc.mrc
3. Configure and Enable Dcc Control from menubar.

Future Plans:

I plan on allowing manipulation of the file based on extension.  Maybe something like a small scripting language, all done through mircscript.  Implement a better options dialog.

Pretty simple eh?  If you find any problems please email me.  Enjoy.
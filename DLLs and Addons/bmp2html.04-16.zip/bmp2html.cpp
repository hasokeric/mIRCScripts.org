#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <windows.h>
#include <string>
#include <fstream>

char*gettok(const char *s, int tok_num, char *d);
int pos(const char *stringin,const char *str,int occurence);
void chartrimleading(char*str,char*trimchar);
void chartrimtrailing(char*str,char*trimchar);
void bmpstringvalid(char*string,unsigned long sizeofarray,unsigned long validcharsneeded);

char*gettok(const char *s, int tok_num, char *d) {
	int count = 0;
	int posnum = 0;
	char* ss = new char[lstrlen(s) + 1]; lstrcpy(ss, s);
	posnum = pos(ss,d,0);
	if (posnum+1 < tok_num) return "";
	if (tok_num == 0) {
		itoa(pos(ss,d,0) + 1,ss,10);
		return ss;
	}
	if (posnum == 0) return ss;
	if (posnum+1 == abs(tok_num)) {
		CopyMemory(&ss[0],&ss[pos(ss,d,posnum) + 1],lstrlen(ss) - (pos(ss,d,posnum) + 1) + 1);
		//return &ss[pos(ss,d,posnum) + 1];
		return ss;
	}
	if (tok_num > 0) ss[pos(ss,d,tok_num)] = '\0';
	if (abs(tok_num) != 1) {
		CopyMemory(&ss[0],&ss[pos(ss,d,abs(tok_num) - 1) + 1],lstrlen(ss) - (pos(ss,d,abs(tok_num) - 1) + 1) + 1);
		return ss;
		//ss = &ss[pos(ss,d,abs(tok_num) - 1)];
		//return &ss[1];
	}
	return ss;
}
int pos(const char *stringin,const char *str,int occurence)
{
   char *pdest = strstr( stringin, str );
   int result = 0;
   int x = 1;
   while ((pdest != NULL) && ((x < occurence) || (occurence == 0))) {
	   x++;
	   pdest = strstr(pdest+lstrlen(str),str);
   }
   if (occurence == 0) return x-1;
   if(pdest != NULL) { result = pdest-stringin; return result; }
   return -1;
}
void bmpstringvalid(char*string,unsigned long sizeofarray,unsigned long validcharsneeded) {
	unsigned long i = 0;
	unsigned long valid = 0;
	char curchar;
	sizeofarray--;
	char*test = new char[1000];
	while (i < sizeofarray && (valid < validcharsneeded || validcharsneeded == 0)) {
		curchar = string[i];
		if (curchar >= 33 && curchar != 173) {
			if (valid != i)	string[valid] = curchar;
			valid++;
		}
		i++;
	}
	string[valid] = '\0';
}
int __stdcall bmp2html(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
	//INPUT: inputfile?outputfile $cr font $cr font-size $cr letter-spacing $cr line-height $cr bgcolor $cr wordsORfileRandomORnot $cr filenameORletters
	char*temp;
	char*temp2;
	char*temp3;
	char*infile;
	char*outfile;
	char*font;
	char*fontsize;
	char*letterspacing;
	char*lineheight;
	char*mode;
	char*information;
	char*bkgcolor;
	temp = gettok(data,0,"\r");
	temp2 = gettok(data,1,"\r");
	temp3 = gettok(temp2,0,"?");
	int filenametype = atoi(temp3);
	if ((atoi(temp) != 8) || (filenametype < 1) || (filenametype > 2)) {
		wsprintf(data, "%s", "E_INSUFFICIENT_PARAMETERS");
		return 3;
	}
	if (atoi(temp3) == 2) {
		infile = gettok(temp2,1,"?");
		outfile = gettok(temp2,2,"?");
	}
	else {
		infile = new char[strlen(temp2) + 1];
		strcpy(infile,temp2);
	}
	delete[] temp;
	delete[] temp2;
	delete[] temp3;
	font = gettok(data,2,"\r");
	fontsize = gettok(data,3,"\r");
	letterspacing = gettok(data,4,"\r");
	lineheight = gettok(data,5,"\r");
	bkgcolor = gettok(data,6,"\r");
	mode = gettok(data,7,"\r");
	information = gettok(data,8,"\r");
	int x = 0;
	int y = 0;
	unsigned long offset = 0;
	unsigned long bmparea;
	long color;
	long lcolor = -1;
	char *hex = new char[10];
	char *FileData;
	char *mycharthing = new char[2];
	mycharthing[1] = '\0';
	char curchar = 6;
	char*str;
	int foundchr = 1;
	int fndchr = 0;
	unsigned long mystrlen = 0;
	HBITMAP mybitmap = (HBITMAP)LoadImage(NULL, infile,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
	if (mybitmap == NULL) {
		//ERROR
		delete[] infile;
		delete[] outfile;
		delete[] font;
		delete[] fontsize;
		delete[] letterspacing;
		delete[] lineheight;
		delete[] bkgcolor;
		delete[] mode;
		delete[] information;
		delete[] mycharthing;
		delete[] hex;
		wsprintf(data,"%s","E_ERROR_LOADING_BITMAP");
		return 3;
	}
	HDC mybitmapDC = CreateCompatibleDC(NULL);
	SelectObject(mybitmapDC, mybitmap);
	LPBITMAPFILEHEADER pBmpFileHeader = (LPBITMAPFILEHEADER) new char[sizeof(BITMAPFILEHEADER)];
	LPBITMAPINFOHEADER pBmpInfoHeader = (LPBITMAPINFOHEADER) new char[sizeof(BITMAPINFOHEADER)];
	HFILE hFile = _lopen( infile, OF_READ);
	if (hFile == HFILE_ERROR) {
		delete[] infile;
		delete[] outfile;
		delete[] font;
		delete[] fontsize;
		delete[] letterspacing;
		delete[] lineheight;
		delete[] bkgcolor;
		delete[] mode;
		delete[] information;
		delete[] mycharthing;
		delete[] hex;
		delete[] pBmpFileHeader;
		delete[] pBmpInfoHeader;
		DeleteObject(mybitmap);
		DeleteDC(mybitmapDC);
		wsprintf(data,"%s","E_ERROR_OPENING_BITMAP");
		return 3;
	}
	_hread( hFile, pBmpFileHeader, sizeof( BITMAPFILEHEADER ) );
	_llseek( hFile, 0, FILE_CURRENT );
	_hread( hFile, pBmpInfoHeader, sizeof(BITMAPINFOHEADER));
	_lclose( hFile );
	int bWidth = pBmpInfoHeader->biWidth;
	int bHeight = pBmpInfoHeader->biHeight;
	bmparea = bWidth * bHeight;
	delete[] pBmpFileHeader;
	delete[] pBmpInfoHeader;
	if (atoi(mode) >= 3) {
		HANDLE file = CreateFile(information,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,NULL,NULL);
		if (file == INVALID_HANDLE_VALUE) {
			delete[] infile;
			delete[] outfile;
			delete[] font;
			delete[] fontsize;
			delete[] letterspacing;
			delete[] lineheight;
			delete[] bkgcolor;
			delete[] mode;
			delete[] information;
			delete[] mycharthing;
			delete[] hex;
			wsprintf(data, "%s", "E_WORDFILE_NOT_FOUND");
			return 3;
		}
		unsigned long FileLength = GetFileSize(file,NULL);
		FileData = new char[FileLength + 1];
		DWORD BytesRead = 0;
		ReadFile(file, FileData, FileLength,&BytesRead,NULL);
		CloseHandle(file);
		delete[] information;
		information = FileData;
		if (atoi(mode) == 3) {
			bmpstringvalid(information,FileLength + 1,bmparea);
			mode[0] = '1';
		}
		else {
			bmpstringvalid(information,FileLength + 1,0);
			mode[0] = '2';
		}
	}
	else {
		if (atoi(mode) == 1) bmpstringvalid(information,strlen(information) + 1,bmparea);
		else bmpstringvalid(information,strlen(information) + 1,0);
	}
	mystrlen = strlen(information);
	offset = mystrlen;
	FILE*stream = fopen("bmp2htmltmpnac.html","wb");
	str = new char[1024];
	str[0] = '\0';
	strcat(str,"<html><title>bmp2html</title><body bgcolor=\"");
	strcat(str,bkgcolor);
	strcat(str,"\"><center>\r\n<!-- start copying here to paste into another file -->\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td style=\"background-color: ");
	strcat(str,bkgcolor);
	strcat(str,";\"><span style=\"white-space: nowrap; font-family: ");
	strcat(str,font);
	strcat(str,", Lucida Console, Keyboard Font, Courier New; font-size: ");
	strcat(str,fontsize);
	strcat(str,"; letter-spacing: ");
	strcat(str,letterspacing);
	strcat(str,"; line-height: ");
	strcat(str,lineheight);
	strcat(str,"; comment: bmp2html\">");
	//echo -a $dll(nacdll\mirc_dll.dll,bmp2html,c:\mirc\arnie.bmp?c:\mirc\bmp2broke.html $+ $cr $+ Courier New $+ $cr $+ 1 $+ $cr $+ 2 $+ $cr $+ 2 $+ $cr $+ 1 $+ $cr $+ asdf)
	fwrite(str,sizeof( char ),strlen(str),stream);
	while (y < bHeight) {
		delete[] str;
		str = new char[1024];
		str[0] = '\0';
		color = (long)GetPixel(mybitmapDC,x,y);
		wsprintf(hex,"%06X",color);
		((USHORT*)hex)[0] ^= ((USHORT*)hex)[2]; ((USHORT*)hex)[2] ^= ((USHORT*)hex)[0]; ((USHORT*)hex)[0] ^= ((USHORT*)hex)[2];
		if (color != lcolor) {
			lcolor = color;
			if (x + y != 0) {
				strcpy(str,"</font><font color=");
			}
			else {
				strcpy(str,"<font color=");
			}
			strcat(str,hex);
			strcat(str,">");
		}
		else {
			strcpy(str,"");
		}
//		

		if (mystrlen) {
			if (atoi(mode) == 2) {
				offset = rand()%mystrlen;
			}
			else {
				offset++;
				if (offset >= mystrlen) offset = 0;
			}
			curchar = information[offset];
		}
		else {
			curchar = '-';
		}
		if (curchar == 60) {
			strcat(str,"&lt;");
		}
		else if (curchar == 62) {
			strcat(str,"&gt;");
		}
		else if (curchar == 38) {
			strcat(str,"&amp;");
		}
		else {
			mycharthing[0] = curchar;
			strcat(str,mycharthing);
		}
//
		fwrite(str,sizeof( char ),strlen(str),stream);
		x++;
		if (x == bWidth) {
			x = 0;
			y++;
			if (y != bHeight) {
				delete[] str;
				str = new char[1024];
				str[0] = '\0';
				strcat(str,"<br>");
				fwrite(str,sizeof( char ),strlen(str),stream);
			}
		}
	}
	delete[] str;
	str = "</font></span></td></tr></table>\r\n<!-- stop copying here -->\r\n<br></center></body></html>";
	fwrite(str,sizeof( char ),strlen(str),stream);
	fclose(stream);
	DeleteObject(mybitmap);
	DeleteDC(mybitmapDC);
	if (filenametype == 2) {
		wsprintf(data, "%s", outfile); 
	}
	else {
		wsprintf(data, "%s%s", infile, ".html"); 
	}
	delete[] infile;
	delete[] outfile;
	delete[] font;
	delete[] fontsize;
	delete[] letterspacing;
	delete[] lineheight;
	delete[] bkgcolor;
	delete[] mode;
	delete[] information;
	delete[] mycharthing;
	delete[] hex;
	if (GetFileAttributes(data) != 0xFFFFFFFF) {
		if (remove(data)) {
			remove("bmp2htmltmpnac.html");
			wsprintf(data,"%s","E_COULD_NOT_OVERWRITE_OUTFILE");
			return 3;
		}
	}
	if (rename("bmp2htmltmpnac.html",data)) {
		remove("bmp2htmltmpnac.html");
		wsprintf(data,"%s","E_COULD_NOT_OVERWRITE_OUTFILE");
		return 3;
	}
	wsprintf(data,"%s","S_OK");
	return 3;
}
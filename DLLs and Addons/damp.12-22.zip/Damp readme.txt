Author: xiao-wen-zi
Email: smallmoskito@yahoo.com
Last update:2002-12-23

Visit my homepage: http://www.ileet.net/~smallmoskito/

Damp is a mp3 player custom built for the "How to build your own picwin mp3 player" tutorial.

To load Damp,

	*run mirc
	*/load -rs <path to damp.mrc>

Damp was coded on mIRC version 6.03 therefore, it is advisable for you to run Damp on mIRC verison 6.03 or above. I do not gurantee its functionality in lower version of mIRC.

To use Damp,
	
	*/damp [skin]

If you specify a skin file when running Damp, you will not be prompted to select a skin file.

Damp skin files are stored in the .dsf format (Damp Skin File, .dsf).

Bugs report and feedbacks can be email to smallmoskito@yahoo.com
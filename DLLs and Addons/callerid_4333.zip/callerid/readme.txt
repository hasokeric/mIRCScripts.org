Open cid.mrc in notepad and follow along how to use it - it is all explained there

NOTE:

   You are Required to have a 'Caller-ID' capable Modem.
   it is not required to have TAPI support.

   I paid my caller id modem about 15$ at local store.

   
   Lets call this the beginning since i want to add a few more things like
   detecting COM port automatically etc... 

   but until then enjoy playing with this toy :)


   COM Port all the way no TAPI!


   RETURN VALUES:

   1 = SUCCESS
   0 = SOMETHING FAILED, COM IS IN USE, WRONG COM PORT ...

   
   Why does it lag when i unload the dll ?

   - It waits for the Event to finish its last process before unloading.

//////////////////////////////////////
//                                  // 
// Cyclopse 2.3 for MTS 1.1         //             
// � by Tampered aka [JH]           //
// Remember, ripping is for lamers! //                       
// Email: jamhar@gmail.com          // 
// MSN: djamz11@hotmail.com         //
//                                  //
//////////////////////////////////////

Installation notes:

- Download the .zip .
- Extract the folder (cyclopse) to your irc directory themes folder, for example C:\Program Files\NoNameScript\themes .
- Run your IRC client .
- Open the MTS or KTE theme engine and apply Cyclopse.mts .
- After applying it is advised you restart your client as all the old theme colours will still be there .

Help notes:

- Please email me at jamhar@gmail.com for help .
- Contact me on IRC at irc.quakenet.org #icecentral .
- MSN djamz11@hotmail.com .
- Visit http://nnscript.de/forum and post for help.

Update notes:

v1.1.2
- 25/11/05 Added new, much cooler status picture.
- 25/11/05 Removed status window picture to save size.
- 25/11/05 Changed brackets to square brackets.
- 25/11/05 Time format changed.

v1.1.1
- 16/08/05 Fixed some colour issues coming up in Red.
- 19/08/05 Some suggestions have been added. ;)

v1.1.0
- 27/08/04 Added image to status window.
- 16/10/04 Fixed additional red/blue colours added.
- 17/10/04 Changed timestamp with another bracket on either side.
- 21/11/04 Changed "was kicked by" to "was booted by".
- 22/11/04 Added swear/abusive words to invite only, banned, full messages when attempting to join a channel.

###################
#                 #
#    HAVE FUN!    #
#                 #
###################
== Axis 2.0 Alpha 5 Readme
 ==========================

Tip: Enable word wrap when reading this file.

This document is provided for helping you to get Axis running. Any other help you may need can be found in Axis itself, by going to 'Script info -> Help' or by typing /xhelp.

Do you feel that this document needs improvements? Let me know!

Contents:

 Installation
 First start
 Performance
 Other notes
 Contact
 Final note

------------------------------------------------------------------------

-- Installation
 ---------------

Installing Axis is very easy. I think the unzipping part can be skipped since you're already reading this file. Well, there's not much left now.

If you have installed mIRC already:
 Go to mIRC's folder (usually c:\mirc), and copy mirc32.exe.
 Go to Axis' folder (usually c:\program files\axis 2.0) and paste it there.
 Now all you have to do is click the file and Axis will start automatically.

If you haven't installed mIRC yet:
 Run the mIRC installer.
 Click "Next", then click "Yes".
 Now you can select the destination folder, which should be the folder you unzipped Axis to.
 Click "Install" and wait until it finishes.
 Now you can start Axis by using the mIRC shortcut in the Start Menu.

You may also want to create a shortcut on your desktop. To do this, drag mirc32.exe to your desktop with the right mouse button and select "create shortcut(s) here".


-- First start
 --------------

When you first start Axis, you have to enter a profile name. It's recommended to only use letters (a-z, A-Z) and numbers (0-9). Spaces and other characters may cause Axis to function incorrect, or not function at all.

The features of Axis can be located under the various popup menus, and there are also some shortcut keys. For more information, please refer to Axis Help.


-- Performance
 ------------------------

There are some features in Axis that may slow down the startup and some other things. To improve performance, try the following:

 - Use the theme 'None.axt' (Control Panel -> Theme)
 - Disable the custom progress bar (Control Panel -> Theme)
 - Disable the sound effects (Control Panel -> General)

Test of an early Alpha 5 on a Pentium 90 with 72 MB RAM and Windows 95C:

 With theme DarkAxis.axt, custom progress bar and sound effects, startup completed in 4.14 seconds.

 With theme None.axt, no custom progress bar and no sound effects, startup completed in 0.782 seconds.


-- Other notes
 --------------

* Scour Exchange has been shut down as of November 16.
The Scour Exchange client is not included in Axis anymore. Future builds will not contain Scour, but it will be available through Axis Update when it works again.

* The ICQ Pager may not always send your message.
I noticed this when I created this feature, and my conclusion was that it doesn't send a message when you've already sent a lot of them in a short time. Send a page to yourself to test it.

* The default mail server may not work.
Enter your ISP's smtp server in the Control Panel for best results. Send an email to yourself to test it. Note that it may take a couple of minutes before the email arrives.

* The BNC services can be used to connect other people to an IRC server via your connection. Be sure to close the port when you're not using it.

* Axis Help is not yet completed.
If you need help, post a message on the messageboard, visit me on IRC, send an ICQ message, or mail me.


-- Contact
 ----------

     Website: http://rb-338.com/axis
Messageboard: http://rb-338.com/cgi-bin/ikonboard/ikonboard.cgi
      E-mail: axis@rb-338.com
     ICQ UIN: 29337990
         IRC: #Axis on irc.axis-web.net (mIRCnet)


-- Final note
 -------------

I hope you enjoy my script as much as I enjoy working on it. To help me making it better, let me know your suggestions and submit bugs to the messageboard. Even if you don't find bugs and don't have questions, I would like to read about your experience with Axis, and eventually what you think may improve the quality of the script.



EOF
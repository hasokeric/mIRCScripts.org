this is the readme file for the Atomic Downloader v1.2

This will basically tell you how to install the Atomic Downloader onto your mirc.

Any help required can be accessed in the help file. If the help file does not answer your question, goto irc.infomatrix.net and /join #atomic

To install the Atomic Downloader:

unzip the zip file into a directory (prefereably the directory where your mirc is located)

open your mirc and type


	 '/load -rs dir/atomic-downloader.ini'


where dir is the directory where you extracted the zip file.


For example:

If I unzip the zip file into c:\mirc\atomic, then i would type 

	'/load -rs atomic/atomic-downloader.ini'


Thankyou and I hope you enjoy using the Atomic Downloader

Any problems or ideas that you come across would be greatly appreciated.

You can logon to irc.infomatrix.net, /join #atomic and leave a message in the channel, or private msg any of the operators. Thankyou

Airplane 3 - By CobaltHex
copyright 2009-2010 PicWin Studios
all assets and code copyright PicWin Studios and Ari Feldman (Airplane and Island Graphics)
--
Readme
--

Airplane 3.5 is the major overhaul of the third in the series and has some of the sprites re-designed, fullscreen capabilities, and much more!

to use, unpack files and load into mIRC(in remotes click load, find the file, and voila! - type /load -rs "path to script\A35.mrc" in the edit box) - there is no need to put the files into the mIRC directory
then, type /A35 to run
to run in fullscreen type /A35 1
or
right click anywhere and select airplane 3 > full screen / windowed
click play and you'll be on your way!
use the arrow keys to move the plane, and space bar to shoot

the objective of the game is to shoot down as many planes as you can, collect powerups, and get as many points as you can

Enjoy!


  Chaos v3 README
  --------------------------------------------
  - Author: Morphy
  - Version: 3.2
  - Date: 03/01/2005 (January 3rd, 2005)
  - E-mail: morphy_chaos@hotmail.com
  --------------------------------------------

  * Optimized for Windows XP with Windows Classic Theme.
  ____________________________________________

  HOW TO INSTALL

  1. Unzip Chaos v3.2.zip to your hard drive (C:\ for example), you don't need to create a folder.
  2. Make sure you have mIRC 6.16. If not, download it at www.mirc.com.
  3. Copy your mirc.exe to the same folder.
  4. Copy bright.fon file from the folder Chaos v3.2\system\ to your WINDOWS\Fonts directory (eg. C:\WINDOWS\Fonts ) and open it. This font is used in Dust theme.
  4. Run mirc.exe.

  ��������������������������������������������
  CONTACT

  You can contact me by mail (morphy_chaos@hotmail.com) about several topics: 
  1. Help with the script (make sure you read the help topics first).
  2. Report a bug in the script.
  3. Suggest what i should add/improve/remove.
  4. Don't ask for latest versions when you can always check yourself (www.chaos.page.vu).

  You can also try posting your doubt/suggestion in Chaos Web Board.
  � http://www.network54.com/Hide/Forum/225565

  ��������������������������������������������
  CREDITS

  Khaled Mardam-Bay		for making mIRC
  Blastball			for being a cool guy, introduced me into scripting
  [-maverick-]			Gave me a couple of ideas and helped me out with the XDCC/Fserve stuff
  DragonZap			for coding the best DLL ever
  Narusegawa-Naru		for systray v2 ;)
  Kamek				for mircustom.dll
  ClickHeRe			for MPopup.dll
  }|-|yRoN{			for hOS.dll
  ooF				for zircx.dll
  BombStrike			for mDock.dll
  Epsilon			for WindowFx.dll
  zAk				Gave me motivation to make the new version and told me about the new docking dlls.
  Beta-Testers			Volumes, Tribe, zAk, etc...
  Bersirc			Icon Package
  BeOS				Icon Package
  QNX				Icon Package
  mircscripts.org		Cool website
  You				:P
  
  ��������������������������������������������

  VERSION HISTORY

  Version 3.2

  Mini mIRC
  New Log Manager
  Dust Theme
  XP Style Popup Menus
  Bandwidth Bar
  DCC Bar
  Mp3 Bar
  mIRC 6.1* Compatible
  Bugs Fixed

  Version 3.1

  XDCC Server
  File Seeker
  File Downloader
  FTP Announcer
  New theme engine
  Better and more advanced popup menus
  File Server fixed
  Mp3 Player updated
  Mp3 Controls in statusbar
  Bugs Fixed

  Version 3.0

  XDCC/Fserv Advertisement Catcher 
  File Server
  New Download Manager 
  Removed some useless stuff 
  New switchbar feature (allowing to see all servers at the same time) 
  Protections 
  Channel WindowFX Bar 
  Seen System 
  Module Updater 
  System Tray Icon (customisable) 
  Channel Scanner 
  E-mail Sender
  Themes Removed (not sure if should use MTS)
  Bugs Fixed 


  Version 2.3

� New switchbar (mIRC style), including popup menus. (100% customisable)
� Toolbar changed a bit, almost no one can tell the difference.
� Made popups for statusbar.
� New sidepanel. Since i removed treeview switchbar, i added a little something below the notify list so you can manage your connections.
� New popup menus.
� Script more customisable. Many more options added to the Configuration.
� The script is now modular.
� New icon package.
  Many configuration dialogs were removed and its options are now in the main Configuration.
  Removed some DLL's, i'm only using 4 dlls now.
� Bugs fixed. 


  Version 2.2
  
� Added a dialog for setup, allowing the user to configure many of the script's features like:
   - Side Panel (notify list, custom switchbar, opaque icons, width, icons, edge and auto-resize)
   - Toolbar: Icons, texts and commands
   - Sounds: The user can now toggle sounds on/off and choose the source files.
   - General options
   - Statusbar: The displayed items can now be chosen.
   - Display Options like toggling custom nicklist, statusbar, custom toolbar...

 �Log Manager updated. Now the logs are organized by networks.
 �Control Panel Updated.
 �Bug fixed in the connect button in the toolbar. 
 �Multiserver compatibility from: statusbar, toolbar, notify list, lag detection, autojoin, switchbar...
 �Made the switchbar multiserver: not sure if it's workin' 100%, but if you do find a bug please report it to Gallagher@mail.pt and i'll fix it to the following version.
 �High-Tec theme changed its font to bright.
 �Added miRC.thm using miRC default colors.
 �Dialog style changed.
 �Removed some useless utilities like calculator, euro converter, hotkeys dialog (this one has been relocated to the setup dialog), and some others.


  Version 2.1
  
  Ram/Lag bars' bug fixed: Whenever main window's height is too small, the text wasn't displayed.
  Added tooltips to switchbar/notify list. 
  Hotkey changed: Ctrl+F4 is no more. Had a complaint that he used that to close the active window. I guess i forgot that... anyways Auto-identify system is now Ctrl+F11. 
  Changed the icons for the notify list (again). 
 

  Version 2.1b

  Control Panel icons updated.
  All of the script's icons have changed.
  New treeview switchbar: New switchbar, this is placed on the right side (for now) and it displays status, channels, querys, DCC's and other windows. It also has a notify list.
  Bottom statusbar: Displays server, uptime, nick and lag.
  Chaos amp: little mp3 player placed on the switchbar.
  Lagbar updated: it's now on the switchbar and it's different.
  Rambar: Also displayed on the switchbar, just below lagbar.
  Main toolbar changed.
  Chaos Help center updated: it now also explains /commands.
  Bugs fixed in themes
  New themes added: Dark Blue (removed), Y2k, Impact, High-Tec, Olive Green, Rain and Silence added.
  New channels nicklist: Nicks now have icons and also have a tooltip with info on the nick.
  Chaos central: Dialog where you check script's news, versions, bug reports, feedback the author and download more themes.
  Bugs fixed in mp3 player.
  Phone Book removed.
  Old lagmeter removed.
  Memo Manager removed.


  Version 2.0

  Control Panel: Allows the user to have a better access to the script's contens. Allows View change (Large, Small, Details).
  Quits Editor updated.
  Beeper: Dialog where the "alarm" trigger can be changed. Now it no longer needs to be "!back".
  CTCP Replies: Dialog where CTCP replies can be chosen. (Time and Version replies)
  Word Correction: If enabled, it replaces the user's error, and shows the words corrected. Dictionary can be altered and more words can be added.
  Chaos Help Center: Very useful when you need help with the script's utilities.
  Themes: No more black and white. In this dialog you can choose from a bigger variety of themes, they can also be previewed before loading.
  New music in Startup Music: Guano Apes and Slipknot removed. Added Oasis and Propellerheads.
  Mp3 Player improved: Created progress bar so that songs can be moved forward and back too. Equalizer created. Visual aspects are now better too... Equalizer and playlist can be displayed or hidden.
  Download Manager: Manage your download folder in this dialog.
  Shitlist v1.0: This is where people you don't like are listed. They can be ignored, unignored... Several options such as kicking, banning, warning...
  Slot Machine: Nice cool game. You start with 1000� and you choose the amount you want to bet (10min 200max). You can also play just for fun with no bets. If you get 3 of the same image you win what you bet. If you only get 2 of the same, you simply don't win or lose. Otherwise you lose what you bet, pretty cool.
  Notify List Dialog improved. Now uses mdx. It echoes a green icon if that person in online and red if offline. Also displays the note and with an option of popping up on connect.
  "About" Dialog.
  Newspaper: Dialog where you can check news like general, sports, weather, movies and chaos script.
  Lagbar: Check you lag here. A bar that displays your lag. Options like color of the bar and delay time added.
  Sports newspaper: Only soccer available for now. Includes results, top scorers and rankings...


  Version 1.1

  Notify List Dialog: Shows the notify nicks that are online at the moment.
  URL List: A dialog where you can save your favorite websites and the respective comment.
  Mp3 Player: Good stuff | Playlist, volume control, file info | Options:( Send message to channel, Shuffle, Repeat...etc).
  Word Effects: Made on channel and query/PVT popups. When selected, if you write normally it comes out - LiKe ThIs, like this or like this.
  Themes (Black and White): Some people complained about the black background, and that they would prefer white... so I put an option that allows to choose between black and white blackgrounds.
  More Status Background Images: I had to make more status background images to the white backgrounds.
  Log Manager: Used to view, delete and organize your logs. Options:(Erase automaticly and seach-a-log system).
  Auto-away System improved: There were some bugs to be fixed... now it's fully operational. (i think...).
  Quiz Game fixed and improved: I fixed some bugs here too, and i added scores, so the people can know their points.
  Channel Status on join: When you join a channel, it shows how many ops, voices and regular users there are.
  ASCII Art removed: only caused lag, it sucked anyway...
  Popups updated.
  Scramble game added: Pretty cool game to play in channel (with scores).
  Hangman game added: The game known as "Forca", a bit changed so it can be played with several people. (with scores).
  New welcome message on start.
  More backgrounds.
  Status Window adjusted for every resolution.
  Chaos Menu Updated.
  Hotkeys Dialog added. The same function as the menu, but more complete.
  Search System: Locate files in your computer. | Results: (dialog or window).
  Chaos Statistics: a dialog where you see your computer, server and script's statistics.
  Nick Completion + Nick Completion Dialog | Options: (On/Off, Nick Type).
  Bugs fixed.


  Best viewed Lucida Console 10
  -EOF-

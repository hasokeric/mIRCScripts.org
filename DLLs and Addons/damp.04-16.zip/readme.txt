Author: xiao-wen-zi
Email: smallmoskito@yahoo.com
Last update:2002-12-23

Visit my homepage: http://smallmoskito.ileet.net/

Damp is a mp3 player custom built for the "How to build your own picwin mp3 player" tutorial.

However, it is now improvised and has alot more function than before!
Check update.txt for more information.

To load Damp,

	*run mirc
	*/load -rs <path to damp.mrc>

Damp was coded on mIRC version 6.03 therefore, it is advisable for you to run Damp on mIRC verison 6.03 or above. I do not gurantee its functionality in lower version of mIRC.

To use Damp,
	
	*/damp [-s]

If you specify the -s parameter, you will be asked to select a skin instead of using the previous skin.

Damp skin files are stored in the .dsf format (Damp Skin File, .dsf).

Keyboard shortcuts
------------------
In player window:

Key		Function
---		--------
z		previous song
x		play song
c		pause song	
v		stop playing
b		next song
delete		eject song
p		open playlist
r		random play
e		repeat 

In playlist

Key		Function
---		--------
arrow up	scroll playlist up
arrow down	scroll playlist down
enter		play selected song
delete		remove selected song

**Ctrl and shift click works with mouse event!

Bugs report and feedbacks can be email to smallmoskito@yahoo.com

Special thanks
--------------

myndzi - for providing some sort of guide when writing the tutorial.
Matrix- and Zack^ - wanted to help me in making the skins, but oh well, the skins never came!
ex|l- - made a few skins and coded the docking playlist(JUST A LINE THOUGH)
 
and many more who have helped me testing the player!!!
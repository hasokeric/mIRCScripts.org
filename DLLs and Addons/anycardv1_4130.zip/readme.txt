Instructions for AnyCard v1 (by moot of DALnet!!!!1) 6/12/08

Installation.  Simply extract the contents of the archive to a subdirectory
called "anycard" within your mirc settings directory which is defined by
$mircdir for you script savvy people out there.  If you're not sure what this
is, it's likely one of two places;

C:\Documents and Settings\(your xp login\Application Data\mIRC\

or

C:\Program Files\mIRC\

Keep in mind that Application Data is a hidden folder and you will need to
adjust your settings in folder options before you have direct access to it.

Once you have the archive extracted to the right place(or think you do), type:

/load -rs anycard/anycard.mrc

If the archive isn't in the right place, it won't load successfully.  If you
get a pop-up following a successful load, just ignore it.

type:

/startgame

to begin.

What kind of card game is this, you say; it's any card game -- hence the name.

My goal from the beginning was to create a 4 player "virtual card table" with
a simple interface and customizeable card deck.  Hopefully that's what I've
achieved here.  The idea is that you and up to three of your friends,
presumably meeting over irc, use this script to connect together and play a
game of cards.

How do you play?

It's not like your typical PC card game where fixed rules allow for fixed
cards and very simple commands.  This is an open card table where you decide
what the rules are.  Try to think of it as a virtual space with a group of 
objects you can manipulate and move around.  I'm simply providing you with
the tools to move them in a way that is more fashionable to a deck of
playing cards.

The layout is relatively simple.  The best way to get fimiliar with the
layout is to load the script and then start a server.  The center of the table
provides an open space for your cards.  The lower "dithered" portion of the
table is where you place cards that you want to see but don't want others to
see.  This area is called the "hand."  Here you can re-order your cards or
simply glance over them without your opponents seeing the face of the cards.
This confidence extends to moving cards out of the hand and to the table.

Below the hand is the "action buffer."  Whenever a card is moved or
manipulated, the action buffer provides a notice of the last action and the
player responsible for making that action.  You can scroll through the action
buffer by clicking the left and right arrow icons just above it or by pressing
the left or right arrow keys on your keyboard.

The top, left and right borders of the table represent the other three player
seats.  The table bitmap and cards have been rotated to be upright for your
position relative to the table.

Last, but not least, is the X which will bring you back to the main menu.
This icon will be replaced with a lightning bolt while the server is busy.

There's 6 primary tools or "card modes."  The current card mode is indicated
by an icon just beneath your mouse cursor when you move your mouse over the
center of the table.  Left clicking will perform an action with the current
card mode, provided you meet the criteria to perform that action.  Right
clicking will cycle through the 6 card modes.  If you find this to be an
annoyance, keys 1-6 on your keyboard provide a quicker version of the same
function.

Card Mode 1 is for moving single cards around.  You can move single cards from
your hand or the table and move them to your hand or the table.  You can also
remove single cards from the top of a stack.  What's a stack? well...

Card Mode 2 is for moving stacks of cards, but may also be used for moving
single cards from either your hand or the table.  However, this mode cannot
remove a single card from the top of a stack.  Stacks are represented by a
stack icon visible on the table.  This mode can merge cards into stacks and
also merge stacks together.  If there's enough room in your hand, you can
move an entire stack to your hand.

Both card modes 1 & 2 are performed via drag and drop.  If you hold a single
card using card mode 1 or 2 and then right click, you will flip the card.
If you hold a stack using card mode 2 and then right click, you will shuffle
the stack.  If the script finds your move to be invalid, it will cancel
the action, placing the card in its' original location.  A cancel is
followed by a very conspicuous "X" in the action buffer to alert you of
the error.

Card Mode 3 is for rotating single cards and stacks of cards on the table.

Card Mode 4 is for flipping single cards on the table.

Card Mode 5 is for peaking at single cards on the table.  Simply click and
hold to view a card without others seeing it, but keep in mind that others
will know you peaked.

Card Mode 6 is for claiming single cards and stacks of cards on the table.
Once you've claimed a card or a stack, nobody can manipulate these cards until
you unclaim them with(the same way you claimed them).  This feature can be
used for a number of reasons, but I had poker chips in mind when I first
implemented it.

Other functions include clicking your player icon to toggle a big "R" which
symbolizes "Ready" but can be used for whatever.  Also, if you click on the
table and no card is present, you perform a "knock" which produces a knocking
sound on every player's PC.

If you're running a server, a few additional functions become available.
Each player-client will have a "K" above their player icon.  You can guess
what clicking the K will do.  If a player disconnects and leaves claimed cards
on the table or cards in their hand, a "U" will appear near your player icon.
Clicking this will clear all claims and empty their hand to the table.  This is
totally optional and you can leave the cards where they are in case a player
wishes to leave and come back or unintentionally disconnects.

If you're joining a server, it should be noted that the player icon with the
"S" atop it is of course the player running the server.

That's the whole interface in a nutshell.  It may seem puzzling initially, but
it's really quite simple.

As I mentioned before, this is a customizeable card game.  When you first load
the script, there's three files listed at the top left of the menu options.
These files dictate the look of the game and the card deck in use.

The first option is the table image, which should be a 700x700 PNG or BMP file
to ensure lossless compression and compatibility with mIRC.  This image is
rotated relative to your player position. If you want to create a table image
that incorporates something that you don't want to have a symmetrical quality
for all sides ... then the option is open.  Also, you should consider that
the useable portion of the table is actually 570 pixels squared and not the
full 700.

The second option is the card deck config.  This is a text file that contains
information about your card deck.  Mainly, the total number of cards, which
images they should use and where they're positioned in the event of a new game.
The script will actually parse through this file to make sure it's formatted
correctly, giving you helpful pointers along the way.

The format is as follows; (bracketed lines are not real lines in the file)

[beginning of file]
(card name)
(total numer of cards) 120 max
[card descriptions from 1 to N]
	(card number)
	(card name -- reserved for the moment) try to limit to 1-9 and A-Z
	(back image ID) 0 - 119
	(front image ID) 0 - 119
	(card type -- also reserved for the moment) must be 1
[end of card descriptions]
(total number of stacks/single cards) 120 max
[stack/single card description from 1 to N]
	(stack/single card number)
	(first card in stack) more on this below
	(last card in stack) more on this below
	(stack/single card X coordinate) 65 - 635
	(stack/single card Y coordinate) 65 - 635
	(stack/single flip flag) 0 or 1, 1 being face down
	(stack/single angle) 1 - 4, 1 is right-side-up, 2-4 are counter clockwise
[end of stack/single card descriptions and end of file]

The first stack must start with the first card in the deck.  Each additional
stack there after will be in ascending order, picking up where the last card of
the last stack left off. This means that the cards within each stack are in
ascending order as well.  If you want to place a single card, then make the
first card and last card in the stack the same value.

If you're still unsure about this, then check the defaultdeck.cfg that comes with
the script.  The script *should* tell you when your config file isn't properly
formatted *and* give an explanation.  If everything appears as it should where the
script is telling you to check for errors, then look farther up the config.

The third option is the card deck image, which should be a 720x800 PNG or BMP file.
The cards should be formatted like so; 60x80 pixels each, 12 across the top and 10
across the side.  Each image is identified in order from left to right, top to bottom
as 0 through 119.  Remember that you can reuse images in the config file to produce 
duplicate cards.

Editing these options or any others can be done by clicking on the appropriate
edit box.  If the entry is satisfactory, the icon to the right of the edit box will
become a check mark.  If not, the icon will become an X.

One last thing of note is server advertising.  I originally began writing this
script with plans for much broader irc incorporation, but the amount of information
involved with synchronizing the card table made this unfeasible.  So, I opted for
something simple.  You can enable this feature if you want to alert your channel 
buddies to your server.

This was my first mIRC script project and I had a lot of fun making it.  Hope you
enjoy the results.

If you have further questions, you can bother me on DALnet by the handle "moot"

No, I'm not *that* moot.
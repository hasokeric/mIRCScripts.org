Readme for Ymar_the_Leprechaun submission to the mircscripts.org IRC-search challenge. For use with mIRC v5.9 only.

-=- Search Options

This addon uses multiple sockets to search any number of IRC servers/networks for information. The networks/servers are fetched from servers.ini, and it may therefore take som time to start the main dialog. To start the addon, type /IRCsearch or select it from the menubar. The available search options are ([] indicates parameters needed):


1. Get information about a nickname [nickname].

This will search the specified servers for a nickname, and get the information you get from a /whois on it.


2. Get the list of users on a channel [channel]

This search type will get you a list of nicknames on the specified channel, by joining it and getting the /names reply. If you want additional information on the users there use search-option 3.


3. Get information about the users on a channel [channel]

Selecting this will make the addon join the channel on all selected servers, and do a /who on it. The information displayed to you will be a formatted version of the information returned. This search option will take longer time than number 2.


4. Mask search [mask]

This search option will /who all selected servers with the mask as parameter. As a result of this, invicible nicks will not be displayed. If the search mask matches to many users, the server might not display all matches.


5. Get a channel listing. [parameters]

Since server parameters to this differ, you will have to specify parameters yourself. (* will in most cases display all channels)


6. Get message of the day.

This option gets the message of the day for all selected servers.


7. Get server links.

This option gets the server links for all selected servers.


-=- Configuration

You can access the configuration dialog with the menu in the main dialog.
Here is an axplanation of all options.

Max # of sim. connections.
	The number specified here will be the maximum number of sockets opened
	by this addon. A low number will result in slower searches, but 
	a number that is to high may result in mIRC being unable to open the 	sockets.

Port selection:
	'Use first port specified in servers.ini' will connect to the servers
	using the first port in the list of ports for that servers.
	'Use the port [port]' will use the specified port.
	Some server ports do not match the ports in servers.ini, so if you are 	having trouble with the connections, use a specified port (6667).

Result display:
	Use the radio buttons here to select what result are to be displayed.

Identd options:
	This enables the addon to run an identd server while searching the 	networks. This is in most cases unnescessary, but may on some servers 	have to be on to connect to it.
	(Running mIRCs own identd server will also work, if it is on all the 	time).


-=- Saving results
You can save results by selecting 'Save results' in the dialog menubar. (The options are only available after a search).



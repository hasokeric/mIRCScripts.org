I guess this is it.

According to the rules of the challenge,
i made an analog and a digital clock
within one custom picture window named @Clock.

The clock types can be changed through buttons
within the picture window.
The window is of course resizable, with
the clock image updated at 1 second intervals.

The main alias is /clock.win,
which shows the clock window and activates the
timer to update the clock.

The script contains few other identifiers to calculate
the X,Y position of the clock parts,
and their colors.

INSIDES.

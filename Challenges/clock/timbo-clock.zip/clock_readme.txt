clk 1.0 
by TiMBo
9-9-00

just load in remotes 
open the clock with /clk
dbbl click or right click popup closes it

I added a titlebar clock as an extra

mp3pro@mail.com
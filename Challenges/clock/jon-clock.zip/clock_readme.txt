A clock by jon (hellish)
mIRC 5.8
----------------------------------------------------

Loading instructions

1. Unzip challenge_clock.mrc and this readme file into any directory.
2. From any window in mIRC, type /load -rs c:\path\path\challenge_clock.mrc or hit Alt-R, choose Load Script from the file menu, and select the file.
3. Clock "Yes" to run the initialization commands.

----------------------------------------------------

Launching the clock

1. Type /clock in any window or
2. Select "Launch analog clock" from the "Clock" menu in the menubar

----------------------------------------------------

Closing the clock

1. Type /clock in any window when the clock is running,
2. Select "Clock analog clock" from the "Clock" menu in the menubar while the clock is running, or
3. Select "Close" from the popup menu in the Clock window.

----------------------------------------------------

Preferences

1. Select "Preferences..." from the "Clock" menu in the menubar or
2. Select "Preferences..." from the popup menu in the Clock window.

Hour hand, Minute hand, Second hand:
When these boxes are checked, the corresponding hand is visible on the Clock window. Atleast one hand must be checked.
Colors can be chosen for the three hands by clicking the corresponding colored box on the right side of the dialog.

% of length:
These editboxes define the length of the three hands. "0%" would completely hide the hand, while "100%" would stretch from the center of the clock to the outside dots.

Dots marking the hour:
Choose the color for every 5th dot (ones which directly designate 1-12) by clicking the corresponding colored box on the right side of the dialog.

Label dots marking the hour:
When this box is checked, every 5th dot will be labeled 1-12. Choose the color of the labels by clicking the box on the right hand side of the dialog.

Show other dots:
When this box is checked, all remaining dots will be shown. Choose the color of the dots by clicking the corresponding box on the right hand side of the dialog.

Background:
Choose the color of the background by clicking the corresponding colored box on the right side of the dialog.

Resize button:
Choose the color of the resize button by clicking the corresponding colored box on the right side of the dialog.

Snap to edge:
When this box is checked, the clock window will snap to the edge when it is within the specified amount of pixels.

----------------------------------------------------

Moving the clock

To move the clock window, click and drag the window.

----------------------------------------------------

Resizing the clock

To resize the clock window, click and drag the resize button in the lower right hand corner of the clock window.

----------------------------------------------------

Size to 324x324

When this popup is visible, the clock will be set so the width and height are equal (set to whichever is larger).

----------------------------------------------------

Unloading instructions

Select "Unload" from the "Clock" menu in the menubar. Cleaning up clock settings will delete the clock_settings.ini file from disk.
www.mircscripts.org clock challenge contribution by Ymar

This will create a clock window from mIRC which will display the current time.

To start the clock type /clock. You can also start it from the menubar.

There are two clock modes available; analog and digital. When in analog mode you can size the window normally (Dragging with your mouse). You can not do this in Digital mode, because the size is fixed to fit the text.You can, however, resize the text either in the settings dialog, or by right clicking in the clock window. The default size is 30 and the font is Arial.

The clock will remeber it's position from the last time you used it, but the desktop position and mdi position is remebered seperately to prevent it from popping up the wrong place if you placed it outside the mdi window when on desktop. (Right-click in the window to switch between desktop and mdi modes).

Most of the features could/should have been made better, but I was too lazy or didn't have the time to do it.

Also, there is an unused portion of the variable used to store information. This is because I changed som of it and didn't bother to change all the numbers in the main file.

Ymar